#include "ppc.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#ifdef __GLIBC__
#include <execinfo.h>
#else
static int backtrace(void **b, int n) { (void)b; (void)n; return 0; }
static void backtrace_symbols_fd(void *const *b, int n, int fd) { (void)b; (void)n; (void)fd; }
#endif
#include <unistd.h>
extern PPCContext *g_ctxp;
#include <sys/time.h>
static void on_prof(int s) { void *bt[12]; int k = backtrace(bt, 12); fprintf(stderr, "[prof]\n"); backtrace_symbols_fd(bt + 2, k - 2 > 5 ? 5 : k - 2, 2); }
static void on_alarm(int s) { fprintf(stderr, "[timeout] travado?\n"); if(getenv("RE1_BT")) { void *bt[40]; int k=backtrace(bt,40); backtrace_symbols_fd(bt,k,2);} fprintf(stderr,"r3=%08X r4=%08X lr=%08X\n",g_ctxp->r[3],g_ctxp->r[4],g_ctxp->lr); ppc_trace_dump(); gx_dump("timeout"); _exit(4); }
#ifdef USE_SDL2
#include <SDL.h>
#endif
PPCContext *g_ctxp;
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "uso: re1gc main.dol [pasta_do_disco_extraido]\n"); return 1; }
    g_mem = calloc(1, PPC_MEM_SIZE);
    hooks_init();
    uint32_t entry;
    if (dol_load(argv[1], &entry)) { fprintf(stderr, "falha ao carregar DOL\n"); return 1; }
#ifdef USE_SDL2
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window *w = SDL_CreateWindow("re1gc", 0, 0, 640, 480, SDL_WINDOW_SHOWN);
    (void)w;
#endif
    if (getenv("RE1_PROF")) { signal(SIGPROF, on_prof); struct itimerval it = {{0, 500000}, {0, 500000}}; setitimer(ITIMER_PROF, &it, 0); }
    { const char *t = getenv("RE1_TIMEOUT"); if (t) { signal(SIGALRM, on_alarm); alarm(atoi(t)); } }
    PPCContext ctx; memset(&ctx, 0, sizeof ctx); g_ctxp=&ctx;
    ctx.spr[287] = 0x00083214;      /* PVR Gekko */
    ctx.msr = 0x00002000;
    /* globais de baixa memoria que o apploader/IPL normalmente deixa */
    ppc_wr32(0x80000028, 0x01800000);   /* tamanho da memoria */
    ppc_wr32(0x800000F8, 162000000);    /* clock do bus */
    ppc_wr32(0x800000FC, 486000000);    /* clock da CPU */
    ppc_wr32(0x80000030, 0);
    ctx.r[1] = 0x817FFF00;
    if (argc > 2 && dvd_init(argv[2])) fprintf(stderr, "aviso: DVD nao inicializado\n");
    printf("entry = 0x%08X\n", entry);
    ppc_call_indirect(&ctx, entry);
    printf("fim: r3=%u r5=%u mem[0x80002000]=%u\n", ctx.r[3], ctx.r[5], ppc_rd32(0x80002000));
    return 0;
}
