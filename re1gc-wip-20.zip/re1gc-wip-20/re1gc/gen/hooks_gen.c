#include "ppc.h"
/* gerado de hooks.txt. Funcoes weak: sobrescreva em runtime/hooks.c */
__attribute__((weak)) void hook_ARQPostRequest(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook_DVDReadAbsAsyncPrio(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook_OSEnableInterrupts(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook_OSRestoreInterrupts(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook_SelectThread(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook___ARChecksize(PPCContext *c) { R(3) = 0; }
__attribute__((weak)) void hook___OSInitAudioSystem(PPCContext *c) { R(3) = 0; }
void hooks_gen_init(void) {
  ppc_register_hook(0x801121C8, hook___OSInitAudioSystem);
  ppc_register_hook(0x80113790, hook_OSEnableInterrupts);
  ppc_register_hook(0x801137A4, hook_OSRestoreInterrupts);
  ppc_register_hook(0x801163F8, hook_SelectThread);
  ppc_register_hook(0x8011B654, hook_DVDReadAbsAsyncPrio);
  ppc_register_hook(0x80121070, hook___ARChecksize);
  ppc_register_hook(0x80121BC8, hook_ARQPostRequest);
}
