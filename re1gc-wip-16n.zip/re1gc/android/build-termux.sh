#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "ERRO: Java nao encontrado. Instale com: pkg install openjdk-17"
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERRO: Gradle nao encontrado. Instale com: pkg install gradle"
  exit 1
fi
if [ -z "${ANDROID_HOME:-}" ]; then
  export ANDROID_HOME="$HOME/android-sdk"
fi
if [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
fi
if [ ! -d "$ANDROID_HOME" ]; then
  echo "ERRO: SDK nao encontrado em $ANDROID_HOME"
  exit 1
fi
export PATH="$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/build-tools/36.0.0:$PATH"

# AGP 8.7.3 do projeto e alinhado com Gradle 8.9. Gere wrapper local para
# evitar tentar compilar com o Gradle 9.x instalado pelo Termux.
if [ ! -x ./gradlew ]; then
  echo "Configurando Gradle Wrapper 8.9..."
  gradle --no-daemon wrapper --gradle-version 8.9 --distribution-type bin
fi

printf '
Java: '; java -version 2>&1 | head -n 1
printf 'SDK: %s
' "$ANDROID_HOME"
printf 'Gradle wrapper: '; ./gradlew --version | grep -m1 '^Gradle '

# O NDK/CMake declarados no app podem ser baixados pelo Android Gradle Plugin.
# Build limitado a 2 workers para reduzir risco de falta de memoria no celular.
./gradlew --no-daemon --max-workers=2 assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  echo
  echo "APK criado: $PWD/$APK"
  ls -lh "$APK"
else
  echo "Build terminou, mas o APK esperado nao foi encontrado: $APK" >&2
  exit 2
fi
