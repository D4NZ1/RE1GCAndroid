package com.example.re1gc;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;

public final class MainActivity extends Activity {
    private static final int PICK_DOL = 41;
    private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("RE1GC — Android experimental"); title.setTextSize(22);
        root.addView(title);
        status = new TextView(this);
        status.setText(NativeBridge.version() + "\n\nSelecione um main.dol extraído de uma cópia própria do jogo. Esta versão integra os módulos PPC, threads OS e DVD HLE, mas ainda não inicia o jogo: a sequência de boot e o renderizador GX precisam ser concluídos.");
        status.setPadding(0, 24, 0, 24); root.addView(status);
        Button pick = new Button(this); pick.setText("Selecionar main.dol");
        pick.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/octet-stream"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_DOL); });
        root.addView(pick); setContentView(root);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_DOL || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); File target = new File(getFilesDir(), "main.dol");
        try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(target)) {
            if (in == null) throw new Exception("Não foi possível abrir o arquivo.");
            byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            int entry = NativeBridge.loadDol(target.getAbsolutePath());
            if (entry < 0) status.setText("Falha ao carregar DOL (código " + entry + "). Confira se selecionou um DOL válido.");
            else status.setText("DOL carregado com sucesso. Entry point: 0x" + Integer.toHexString(entry).toUpperCase() + "\n\nRuntime PPC + módulos de threads/DVD incluídos. O jogo ainda não foi executado: falta validar a sequência de boot e implementar GX para desenhar as cenas.");
        } catch (Exception e) { status.setText("Erro: " + e.getMessage()); }
    }
    @Override protected void onDestroy() { NativeBridge.destroy(); super.onDestroy(); }
}
