#!/usr/bin/env python3
"""Gera um DOL sintetico minimo para testar o pipeline (sem jogo)."""
import struct, sys
code = [0x38600005, 0x38800007,
        (31<<26)|(5<<21)|(3<<16)|(4<<11)|(266<<1),
        0x3CC08000,
        (36<<26)|(5<<21)|(6<<16)|0x2000,
        (18<<26)|8|1,
        0x4E800020,
        (14<<26)|(5<<21)|(5<<16)|1,
        0x4E800020]
blob = b"".join(struct.pack(">I", w) for w in code)
h = [0] * 64
h[0] = 0x100; h[18] = 0x80003100; h[36] = len(blob); h[56] = 0x80003100
open(sys.argv[1], "wb").write(struct.pack(">64I", *h) + blob)
