#!/bin/sh
# build rapido de debug (-O0), sem CMake, em paralelo e incremental. Uso: sh tools/build_debug.sh  (EXTRA=-DFLAG opcional)
cd "$(dirname "$0")/.."
mkdir -p build
CF="${EXTRA} -O0 -w -g -rdynamic -Iruntime -Igen -std=gnu11"
ls gen/*.c runtime/*.c | xargs -P $(nproc) -I{} sh -c 'o=build/$(basename {} .c).o; [ -f $o ] && [ $o -nt {} ] && [ $o -nt runtime/ppc.h ] || gcc '"$CF"' -c {} -o $o'
gcc -rdynamic build/*.o -o build/re1gc -lm -lpthread
