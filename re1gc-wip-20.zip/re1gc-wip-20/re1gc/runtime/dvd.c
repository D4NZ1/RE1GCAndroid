/* DVD em HLE: o disco e uma pasta extraida (nodtool: sys/ e files/). O FST (sys/fst.bin) e colocado na RAM
   como o apploader faria (0x80000038), e a leitura absoluta (DVDReadAbsAsyncPrio) e atendida direto dos arquivos. */
#include "ppc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FST_ADDR 0x817E0000u
typedef struct { uint32_t off, len; char *path; } DFile;
static DFile *s_files; static int s_nf; static char s_root[1024];
static FILE *s_fp; static int s_fp_idx = -1;

static int cmp_off(const void *a, const void *b) { uint32_t x = ((const DFile *)a)->off, y = ((const DFile *)b)->off; return x < y ? -1 : x > y; }

static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }

static void walk(const uint8_t *fst, const char *names, uint32_t n, uint32_t i, uint32_t end, const char *pre) {
    while (i < end) {
        const uint8_t *e = fst + 12 * i;
        uint32_t no = be32(e) & 0xFFFFFF; int dir = e[0];
        const char *nm = names + no;
        char *path = malloc(strlen(pre) + strlen(nm) + 2);
        if (dir) { sprintf(path, "%s%s/", pre, nm); walk(fst, names, n, i + 1, be32(e + 8), path); free(path); i = be32(e + 8); }
        else { s_files = realloc(s_files, (s_nf + 1) * sizeof *s_files);
               sprintf(path, "%s%s", pre, nm);
               s_files[s_nf].off = be32(e + 4); s_files[s_nf].len = be32(e + 8); s_files[s_nf].path = path; s_nf++; i++; }
    }
}

int dvd_init(const char *root) {
    snprintf(s_root, sizeof s_root, "%s", root);
    char p[1200]; snprintf(p, sizeof p, "%s/sys/fst.bin", root);
    FILE *f = fopen(p, "rb"); if (!f) { fprintf(stderr, "[dvd] sem %s\n", p); return -1; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    if (sz < 12 || sz > 0x10000) { fprintf(stderr, "[dvd] fst.bin invalido (%ld bytes)\n", sz); fclose(f); return -1; }
    uint8_t *buf = malloc(sz);
    if (fread(buf, 1, sz, f) != (size_t)sz) { fclose(f); free(buf); return -1; }
    fclose(f);
    uint32_t n = be32(buf + 8);
    if (n < 1 || n * 12 > (uint32_t)sz) { fprintf(stderr, "[dvd] fst.bin corrompido\n"); free(buf); return -1; }
    memcpy(ppc_ptr(FST_ADDR), buf, sz);
    ppc_wr32(0x80000038, FST_ADDR); ppc_wr32(0x8000003C, (uint32_t)sz);
    /* cabecalho do disco (ID do jogo etc.) em 0x80000000, se houver boot.bin */
    snprintf(p, sizeof p, "%s/sys/boot.bin", root);
    if ((f = fopen(p, "rb"))) { uint8_t h[0x20]; if (fread(h, 1, 0x20, f) == 0x20) memcpy(ppc_ptr(0x80000000), h, 0x20); fclose(f); }
    walk(buf, (const char *)buf + 12 * n, n, 1, n, "");
    qsort(s_files, s_nf, sizeof *s_files, cmp_off);
    free(buf);
    fprintf(stderr, "[dvd] %d arquivos, FST em 0x%08X\n", s_nf, FST_ADDR);
    return 0;
}

/* le 'len' bytes do offset absoluto 'off' do disco para a RAM em 'dst'; fora de qualquer arquivo = zeros */
static void disc_read(uint32_t dst, uint32_t len, uint32_t off) {
    static unsigned char tmp[1 << 16];
    while (len) {
        int lo = 0, hi = s_nf - 1, idx = -1;
        while (lo <= hi) { int m = (lo + hi) / 2; if (s_files[m].off <= off) { idx = m; lo = m + 1; } else hi = m - 1; }
        uint32_t chunk = len;
        int in_file = idx >= 0 && off < s_files[idx].off + s_files[idx].len;
        if (in_file) { uint32_t rem = s_files[idx].off + s_files[idx].len - off; if (chunk > rem) chunk = rem; }
        else { uint32_t nxt = idx + 1 < s_nf ? s_files[idx + 1].off : 0xFFFFFFFFu; if (nxt - off < chunk) chunk = nxt - off; }
        if (in_file) {
            if (s_fp_idx != idx) {
                if (s_fp) fclose(s_fp);
                char p[1500]; snprintf(p, sizeof p, "%s/files/%s", s_root, s_files[idx].path);
                s_fp = fopen(p, "rb"); s_fp_idx = idx;
                if (!s_fp) fprintf(stderr, "[dvd] nao abriu %s\n", p);
            }
            if (s_fp) fseek(s_fp, off - s_files[idx].off, SEEK_SET);
            for (uint32_t done = 0; done < chunk;) {
                uint32_t k = chunk - done > sizeof tmp ? sizeof tmp : chunk - done;
                size_t r = s_fp ? fread(tmp, 1, k, s_fp) : 0;
                if (r < k) memset(tmp + r, 0, k - r);
                for (uint32_t i = 0; i < k; i++) ppc_wr8(dst + done + i, tmp[i]);
                done += k;
            }
        } else for (uint32_t i = 0; i < chunk; i++) ppc_wr8(dst + i, 0);
        dst += chunk; off += chunk; len -= chunk;
    }
}

/* DVDReadAbsAsyncPrio (0x8011B654): r3=block r4=addr r5=len r6=offset abs r7=callback r8=prio.
   DVDCommandBlock: state +0x0C, offset +0x10, length +0x14, addr +0x18, transferred +0x20, callback +0x28. */
void hook_DVDReadAbsAsyncPrio(PPCContext *c) {
    uint32_t blk = R(3), addr = R(4), len = R(5), off = R(6), cb = R(7);
    if (getenv("RE1_DVD")) fprintf(stderr, "[dvd] read off=0x%08X len=0x%X -> 0x%08X\n", off, len, addr);
    disc_read(addr, len, off);
    ppc_wr32(blk + 0x08, 1); ppc_wr32(blk + 0x0C, 0);           /* command READ, state = END */
    ppc_wr32(blk + 0x10, off); ppc_wr32(blk + 0x14, len); ppc_wr32(blk + 0x18, addr);
    ppc_wr32(blk + 0x20, len); ppc_wr32(blk + 0x28, cb);
    if (cb) ppc_queue_callback(cb, len, blk);
    R(3) = 1;
}
