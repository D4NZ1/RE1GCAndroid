/* Threads do OS (HLE): hook de SelectThread (0x801163F8).
   Toda a logica de filas/estados/prioridades continua sendo o codigo original do jogo (OSCreateThread,
   OSSleepThread, OSWakeupThread, mutex, message queues...). So a troca de contexto, que usa
   OSSaveContext/OSLoadContext (asm), e feita aqui, com ucontext (troca cooperativa no host).
   Layout (OSThread): context 0x000 (gpr, cr 0x80, lr 0x84, ctr 0x88, xer 0x8C, fpr 0x90, srr0 0x198, srr1 0x19C),
   state 0x2C8, prio 0x2D0, queue 0x2DC, link.next 0x2E0, link.prev 0x2E4. */
#define _GNU_SOURCE
#include "ppc.h"
#include "recomp_funcs.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define OS_CURRENT_THREAD 0x800000E4u
#define T_STATE 712
#define T_PRIO 720
#define T_QUEUE 732
#define T_NEXT 736
#define T_PREV 740
#define RUNQ_BASE 0x80230838u           /* RunQueue[32] {head, tail} */
#define IDLE_CTX (RUNQ_BASE + 1824)    /* IdleContext */
#define STK_SIZE (4u << 20)

typedef struct Th { uint32_t os; PPCContext *c; int started; struct Th *next; } Th;
static Th *s_th; static Th *s_cur;

/* Troca cooperativa com pthreads (bionic/Android nao tem ucontext): so a thread que detem o "bastao" executa. */
static pthread_mutex_t s_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_cv = PTHREAD_COND_INITIALIZER;
static Th *s_baton;
static void baton_wait(Th *me) {
    pthread_mutex_lock(&s_mu);
    while (s_baton != me) pthread_cond_wait(&s_cv, &s_mu);
    pthread_mutex_unlock(&s_mu);
}
static void baton_switch(Th *from, Th *to) {
    pthread_mutex_lock(&s_mu);
    s_baton = to; pthread_cond_broadcast(&s_cv);
    while (s_baton != from) pthread_cond_wait(&s_cv, &s_mu);
    pthread_mutex_unlock(&s_mu);
}
static void th_entry(void);
static void *th_main(void *arg) { baton_wait((Th *)arg); th_entry(); return NULL; }

static Th *th_find(uint32_t os) { for (Th *t = s_th; t; t = t->next) if (t->os == os) return t; return NULL; }
static Th *th_get(uint32_t os) {
    Th *t = th_find(os); if (t) return t;
    t = calloc(1, sizeof *t); t->os = os; t->next = s_th; s_th = t; return t;
}

static void th_entry(void) {
    Th *t = s_cur; PPCContext *c = t->c; uint32_t os = t->os;
    memset(c, 0, sizeof *c);
    for (int i = 0; i < 32; i++) { c->r[i] = ppc_rd32(os + 4 * i); c->f[i] = ppc_rdf64(os + 0x90 + 8 * i); c->p1[i] = c->f[i]; }
    c->cr = ppc_rd32(os + 0x80); c->lr = ppc_rd32(os + 0x84); c->ctr = ppc_rd32(os + 0x88); c->xer = ppc_rd32(os + 0x8C);
    c->msr = ppc_rd32(os + 0x19C) | 0x2000; c->spr[287] = 0x00083214;
    for (int i = 0; i < 8; i++) c->spr[912 + i] = 0;
    uint32_t entry = ppc_rd32(os + 0x198), lr = c->lr;
    if (getenv("RE1_THR")) fprintf(stderr, "[thr] start %08X entry=%08X r1=%08X r3=%08X lr=%08X\n", os, entry, c->r[1], c->r[3], lr);
    ppc_call_indirect(c, entry);
    if (lr) { c->lr = 0; ppc_call_indirect(c, lr); }   /* OSExitThread(r3) */
    for (;;) hook_SelectThread(c);                      /* nunca deveria voltar */
}

static void dump_threads(void) {
    for (Th *t = s_th; t; t = t->next) {
        fprintf(stderr, "[thr] %08X state=%u prio=%u entry=%08X queue=%08X lr=%08X\n", t->os, ppc_rd16(t->os + T_STATE), ppc_rd32(t->os + T_PRIO),
                ppc_rd32(t->os + 0x198), ppc_rd32(t->os + T_QUEUE), t->c ? t->c->lr : 0);
    if (t->c) { uint32_t sp = t->c->r[1]; fprintf(stderr, "      pilha PPC:");
        for (int i = 0; i < 10 && sp >= 0x80000000u && sp < 0x81800000u; i++) { uint32_t nx = ppc_rd32(sp); fprintf(stderr, " %08X", ppc_rd32(nx + 4)); if (nx <= sp) break; sp = nx; }
        fprintf(stderr, "\n"); }
    }
}
static void idle_wait(PPCContext *c) {
    static int n; const char *d = getenv("RE1_DUMP"); if ((getenv("RE1_THR") || d) && ++n == (d ? atoi(d) : 25)) dump_threads();
    /* ninguem pronto: deixa o "hardware" simulado andar (ARQ/DSP/VI) e deixa 1 quadro (60 Hz) passar */
    struct timespec ts = {0, 1000000000L / 60}; nanosleep(&ts, NULL);
    c->msr |= 0x8000u; ppc_deliver_irqs(c); ppc_vi_tick(c);
}

void hook_SelectThread(PPCContext *c) {
    uint32_t yield = R(3);
    { static int n; const char *e = getenv("RE1_THR"); int sk = e ? atoi(e) - 1 : 0; if (e && n++ >= sk && n < sk + 31) fprintf(stderr, "[sel] main.st=%u wrk.st=%u yield=%u cur=%08X bits=%08X resched=%d ctx=%08X\n", ppc_rd16(0x80230C48 + T_STATE), ppc_rd16(0x8021ED98 + T_STATE), yield, ppc_rd32(OS_CURRENT_THREAD), ppc_rd32(R(13) - 30128), (int)ppc_rd32(R(13) - 30120), ppc_rd32(0x800000D4)); }
    if ((int32_t)ppc_rd32(R(13) - 30120) > 0) { R(3) = 0; return; }       /* Reschedule */
    R(3) = ppc_rd32(0x800000D4);                                          /* OSGetCurrentContext */
    uint32_t cur = ppc_rd32(OS_CURRENT_THREAD);
    if (R(3) != cur) { R(3) = 0; return; }                                   /* fora de contexto de thread */
    uint32_t bits = ppc_rd32(R(13) - 30128);
    if (cur) {
        if (ppc_rd16(cur + T_STATE) == 2) {
            uint32_t prio = ppc_rd32(cur + T_PRIO);
            int best = bits ? __builtin_clz(bits) : 32;
            if (!yield && (int32_t)prio <= best) { R(3) = 0; return; }       /* continua rodando */
            uint32_t q = RUNQ_BASE + prio * 8;
            ppc_wr16(cur + T_STATE, 1); ppc_wr32(cur + T_QUEUE, q);
            uint32_t tail = ppc_rd32(q + 4);
            if (tail) { ppc_wr32(tail + T_NEXT, cur); ppc_wr32(cur + T_PREV, tail); } else ppc_wr32(q, cur);
            ppc_wr32(cur + T_NEXT, 0); ppc_wr32(q + 4, cur);
            ppc_wr32(R(13) - 30128, ppc_rd32(R(13) - 30128) | (1u << (31 - prio)));
            ppc_wr32(R(13) - 30124, 1);
        }
    }
    ppc_wr32(OS_CURRENT_THREAD, 0);
    bits = ppc_rd32(R(13) - 30128);
    if (!bits) {
        R(3) = IDLE_CTX; f_80112D40(c);                                     /* OSSetCurrentContext(IdleContext) */
        for (;;) {
            if (ppc_rd32(R(13) - 30128)) break;
            idle_wait(c);
        }
        R(3) = IDLE_CTX; f_80112F08(c);                                     /* OSClearContext(IdleContext) */
        bits = ppc_rd32(R(13) - 30128);
    }
    ppc_wr32(R(13) - 30124, 0);
    int prio = __builtin_clz(bits);
    uint32_t q = RUNQ_BASE + prio * 8, next = ppc_rd32(q), nn = ppc_rd32(next + T_NEXT);
    if (nn) ppc_wr32(nn + T_PREV, 0); else ppc_wr32(q + 4, 0);
    ppc_wr32(q, nn);
    if (!ppc_rd32(q)) ppc_wr32(R(13) - 30128, ppc_rd32(R(13) - 30128) & ~(1u << (31 - prio)));
    ppc_wr32(next + T_QUEUE, 0); ppc_wr16(next + T_STATE, 2);
    ppc_wr32(OS_CURRENT_THREAD, next);
    R(3) = next; f_80112D40(c);                                              /* OSSetCurrentContext(&next->context) */
    { static int m; if (getenv("RE1_SW") && m++ < 90 && m > 40) fprintf(stderr, "[sw] %08X -> %08X (lr=%08X)\n", cur, next, R(3) ? 0 : c->lr); }
    if (next != cur) {
        Th *from = th_get(cur ? cur : 0), *to = th_get(next);
        from->c = c; from->started = 1;
        if (!to->started) {
            to->started = 1; to->c = calloc(1, sizeof(PPCContext));
            pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, STK_SIZE);
            pthread_t tid; pthread_create(&tid, &at, th_main, to); pthread_detach(tid); pthread_attr_destroy(&at);
        }
        s_cur = to;
        baton_switch(from, to);
        s_cur = from;                                                        /* voltamos: somos 'from' de novo */
    }
    R(3) = 0;
}
