#!/usr/bin/env python3
"""Lifter PowerPC (Gekko) -> C.  Uso: ppclift.py main.dol -o gen [--hooks hooks.txt]
Cobre inteiros, floats, paired singles e instrucoes de sistema comuns do GameCube.
O que faltar vira ppc_unimpl() e aparece no relatorio."""
import struct, sys, os, argparse, collections

def sx(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v & (1 << (bits - 1)) else v

VALID_OPS = set(range(64)) - {0, 1, 2, 5, 6, 9, 22, 30, 58, 62}
BLR = 0x4E800020

class Dol:
    def __init__(s, data):
        h = struct.unpack(">" + "I" * 64, data[:0x100])
        s.data = data
        s.text = [(h[i], h[18 + i], h[36 + i]) for i in range(7) if h[36 + i]]
        s.datas = [(h[7 + i], h[25 + i], h[43 + i]) for i in range(11) if h[43 + i]]
        s.entry = h[56]
    def in_text(s, a):
        return a % 4 == 0 and any(b <= a < b + n for _, b, n in s.text)
    def word(s, a):
        for off, b, n in s.text:
            if b <= a < b + n:
                return struct.unpack(">I", s.data[off + a - b: off + a - b + 4])[0]
        raise ValueError("addr fora do texto %08X" % a)
    def words(s, off, n):
        return struct.unpack(">%dI" % (n // 4), s.data[off:off + n])

def mask(mb, me):
    if mb <= me:
        return ((0xFFFFFFFF >> mb) & (0xFFFFFFFF << (31 - me))) & 0xFFFFFFFF
    return (~mask(me + 1, mb - 1)) & 0xFFFFFFFF

def is_boundary(w):
    """palavra que costuma vir antes do inicio de uma funcao"""
    return w in (BLR, 0x4E800420, 0x4E800020) or w == 0 or (w >> 26 == 18 and not w & 1) or w == 0x60000000

# ---------- descoberta de funcoes ----------
def scan(dol, f, hooks, starts):
    a, maxbr, calls, jumps, valid = f, f, [], [], True
    while dol.in_text(a):
        if a != f and a in starts: break
        w = dol.word(a); op = w >> 26
        if op not in VALID_OPS: valid = False
        term = False
        if op == 18:
            li = sx(w & 0x03FFFFFC, 26)
            t = li & 0xFFFFFFFF if w & 2 else (a + li) & 0xFFFFFFFF
            if w & 1: calls.append(t)
            else:
                jumps.append(t)
                if t > a and t not in starts: maxbr = max(maxbr, t)
                term = True
        elif op == 16:
            d = sx(w & 0xFFFC, 16)
            t = d & 0xFFFFFFFF if w & 2 else (a + d) & 0xFFFFFFFF
            if w & 1:
                if t != a + 4: calls.append(t)
            else:
                jumps.append(t)
                if t > a and t not in starts: maxbr = max(maxbr, t)
        elif op == 19 and ((w >> 1) & 0x3FF) in (16, 528) and ((w >> 21) & 31) == 20 and not (w & 1):
            term = True
        a += 4
        if term and a > maxbr: break
    end = a
    for t in jumps:
        if not (f <= t < end): calls.append(t)
    return end, [c for c in calls if dol.in_text(c) and c not in hooks], valid

def prologue_candidates(dol):
    out = set()
    for off, base, n in dol.text:
        ws = dol.words(off, n)
        for i, w in enumerate(ws):
            if w == 0x7C0802A6:      # mflr r0
                win = ws[i:i + 4]
                if any((x >> 16) == 0x9421 and x & 0x8000 for x in win): start = i
                else: continue
            elif (w >> 16) == 0x9421 and w & 0x8000:   # stwu r1,-N(r1)
                if any(x == 0x7C0802A6 for x in ws[i:i + 4]): start = i
                else: continue
            else: continue
            if start == 0 or is_boundary(ws[start - 1]):
                out.add(base + 4 * start)
    return out

def data_pointers(dol):
    out = set()
    tb = {}
    for off, b, n in dol.text: tb[b] = (off, n)
    for off, base, n in dol.datas:
        for v in dol.words(off, n - n % 4):
            if v % 4 == 0 and dol.in_text(v) and v != dol.entry:
                try:
                    if is_boundary(dol.word(v - 4)) if dol.in_text(v - 4) else True:
                        out.add(v)
                except ValueError: pass
    return out

def immediate_pointers(dol):
    """enderecos de funcao carregados por lis+addi/ori (ex.: handler passado a OSSetInterruptHandler)"""
    out = set()
    for off, base, n in dol.text:
        ws = dol.words(off, n)
        for i, w in enumerate(ws):
            if (w >> 26) != 15 or ((w >> 16) & 31) != 0: continue      # lis rD, imm
            rd, hi = (w >> 21) & 31, (w & 0xFFFF) << 16
            for x in ws[i + 1:i + 7]:
                op = x >> 26
                if op == 14 and ((x >> 16) & 31) == rd: lo = x & 0xFFFF; v = hi + (lo - 0x10000 if lo & 0x8000 else lo)
                elif op == 24 and ((x >> 21) & 31) == rd: v = hi | (x & 0xFFFF)
                else: continue
                v &= 0xFFFFFFFF
                if v % 4 == 0 and dol.in_text(v) and v != dol.entry:
                    try:
                        if not dol.in_text(v - 4) or is_boundary(dol.word(v - 4)): out.add(v)
                    except ValueError: pass
    return out

def discover(dol, hooks):
    soft = (prologue_candidates(dol) | data_pointers(dol) | immediate_pointers(dol)) - hooks
    starts = {dol.entry} | soft
    funcs = {}
    work = [dol.entry]
    soft_work = sorted(soft)
    def process(f, hard):
        end, calls, valid = scan(dol, f, hooks, starts)
        if not hard and not valid: starts.discard(f); return []
        funcs[f] = end
        for c in calls: starts.add(c)
        return [c for c in calls if c not in funcs]
    while work or soft_work:
        while work:
            f = work.pop()
            if f in funcs or f in hooks: continue
            work += process(f, True)
        while soft_work and not work:
            f = soft_work.pop()
            if f in funcs: continue
            work += process(f, False)
    # reescaneia com o conjunto final de inicios
    for _ in range(3):
        changed = False
        for f in sorted(funcs):
            end, calls, valid = scan(dol, f, hooks, starts)
            if end != funcs[f]: funcs[f] = end; changed = True
            for c in calls:
                if c not in funcs and c not in hooks and dol.in_text(c):
                    starts.add(c)
                    e2, c2, v2 = scan(dol, c, hooks, starts); funcs[c] = e2; changed = True
        if not changed: break
    return funcs

# ---------- traducao de instrucoes ----------
def branch_cond(w):
    bo, bi = (w >> 21) & 31, (w >> 16) & 31
    pre, parts = [], []
    if not bo & 4:
        pre.append("c->ctr--;")
        parts.append("(c->ctr %s 0)" % ("==" if bo & 2 else "!="))
    if not bo & 16:
        parts.append("(((c->cr >> %d) & 1) == %d)" % (31 - bi, (bo >> 3) & 1))
    return pre, " && ".join(parts)

XO_SET = {266, 40, 235, 104, 10, 138, 202, 234, 8, 136, 200, 75, 11, 491, 459}
NOP = ["/* nop */"]

def lift(a, w, f, end, funcs, hooks):
    op = w >> 26
    rd, ra, rb = (w >> 21) & 31, (w >> 16) & 31, (w >> 11) & 31
    rc_ = (w >> 6) & 31
    simm, uimm = sx(w, 16), w & 0xFFFF
    rc = w & 1
    RA0 = "0" if ra == 0 else "R(%d)" % ra
    EA = "(%s + (%d))" % (RA0, simm)
    EAX = "(%s + R(%d))" % (RA0, rb)
    crf = (w >> 23) & 7
    F = lambda n: "c->f[%d]" % n
    P = lambda n: "c->p1[%d]" % n
    def cr0(r): return ["ppc_cr0(c, (int32_t)R(%d));" % r] if rc else []
    def call(t):
        if t in funcs and t not in hooks: return "f_%08X(c);" % t
        return "ppc_call_indirect(c, 0x%08X);" % t
    def local(t): return f <= t < end and not (t in funcs and t != f)

    if op == 3: return NOP  # twi
    if op == 17: return NOP  # sc: o SDK usa como barreira apos dcbf
    if op == 7:  return ["R(%d) = (uint32_t)((int32_t)R(%d) * (%d));" % (rd, ra, simm)]
    if op == 8:  return ["ppc_adde(c, %d, ~R(%d), 0x%08Xu, 1);" % (rd, ra, simm & 0xFFFFFFFF)]
    if op == 12: return ["ppc_adde(c, %d, R(%d), 0x%08Xu, 0);" % (rd, ra, simm & 0xFFFFFFFF)]
    if op == 13: return ["ppc_adde(c, %d, R(%d), 0x%08Xu, 0);" % (rd, ra, simm & 0xFFFFFFFF), "ppc_cr0(c, (int32_t)R(%d));" % rd]
    if op == 14: return ["R(%d) = %s + (%d);" % (rd, RA0, simm)]
    if op == 15: return ["R(%d) = %s + 0x%08Xu;" % (rd, RA0, (uimm << 16) & 0xFFFFFFFF)]
    if op == 24: return ["R(%d) = R(%d) | 0x%Xu;" % (ra, rd, uimm)]
    if op == 25: return ["R(%d) = R(%d) | 0x%Xu;" % (ra, rd, uimm << 16)]
    if op == 26: return ["R(%d) = R(%d) ^ 0x%Xu;" % (ra, rd, uimm)]
    if op == 27: return ["R(%d) = R(%d) ^ 0x%Xu;" % (ra, rd, uimm << 16)]
    if op == 28: return ["R(%d) = R(%d) & 0x%Xu;" % (ra, rd, uimm), "ppc_cr0(c, (int32_t)R(%d));" % ra]
    if op == 29: return ["R(%d) = R(%d) & 0x%Xu;" % (ra, rd, uimm << 16), "ppc_cr0(c, (int32_t)R(%d));" % ra]
    if op == 20:
        sh, mb, me = rb, (w >> 6) & 31, (w >> 1) & 31; m = mask(mb, me)
        return ["R(%d) = (ppc_rotl(R(%d), %d) & 0x%08Xu) | (R(%d) & 0x%08Xu);" % (ra, rd, sh, m, ra, ~m & 0xFFFFFFFF)] + cr0(ra)
    if op == 21:
        sh, mb, me = rb, (w >> 6) & 31, (w >> 1) & 31
        return ["R(%d) = ppc_rotl(R(%d), %d) & 0x%08Xu;" % (ra, rd, sh, mask(mb, me))] + cr0(ra)
    if op == 23:
        mb, me = (w >> 6) & 31, (w >> 1) & 31
        return ["R(%d) = ppc_rotl(R(%d), R(%d)) & 0x%08Xu;" % (ra, rd, rb, mask(mb, me))] + cr0(ra)
    # loads/stores inteiros
    loads = {32: "ppc_rd32(%s)", 34: "ppc_rd8(%s)", 40: "ppc_rd16(%s)",
             42: "(uint32_t)(int32_t)(int16_t)ppc_rd16(%s)"}
    if op in loads: return ["R(%d) = %s;" % (rd, loads[op] % EA)]
    upd_l = {33: "ppc_rd32(R(%d))", 35: "ppc_rd8(R(%d))", 41: "ppc_rd16(R(%d))",
             43: "(uint32_t)(int32_t)(int16_t)ppc_rd16(R(%d))"}
    if op in upd_l:
        return ["R(%d) = R(%d) + (%d);" % (ra, ra, simm), "R(%d) = %s;" % (rd, upd_l[op] % ra)]
    stores = {36: "ppc_wr32", 38: "ppc_wr8", 44: "ppc_wr16"}
    if op in stores: return ["%s(%s, R(%d));" % (stores[op], EA, rd)]
    upd_s = {37: "ppc_wr32", 39: "ppc_wr8", 45: "ppc_wr16"}
    if op in upd_s:
        return ["{ uint32_t ea = R(%d) + (%d); %s(ea, R(%d)); R(%d) = ea; }" % (ra, simm, upd_s[op], rd, ra)]
    if op == 46: return ["for (int i = %d; i < 32; i++) R(i) = ppc_rd32(%s + 4 * (i - %d));" % (rd, EA, rd)]
    if op == 47: return ["for (int i = %d; i < 32; i++) ppc_wr32(%s + 4 * (i - %d), R(i));" % (rd, EA, rd)]
    # floats load/store
    if op == 48: return ["%s = ppc_rdf32(%s); %s = %s;" % (F(rd), EA, P(rd), F(rd))]
    if op == 49: return ["{ uint32_t ea = R(%d) + (%d); %s = ppc_rdf32(ea); %s = %s; R(%d) = ea; }" % (ra, simm, F(rd), P(rd), F(rd), ra)]
    if op == 50: return ["%s = ppc_rdf64(%s);" % (F(rd), EA)]
    if op == 51: return ["{ uint32_t ea = R(%d) + (%d); %s = ppc_rdf64(ea); R(%d) = ea; }" % (ra, simm, F(rd), ra)]
    if op == 52: return ["ppc_wrf32(%s, (float)%s);" % (EA, F(rd))]
    if op == 53: return ["{ uint32_t ea = R(%d) + (%d); ppc_wrf32(ea, (float)%s); R(%d) = ea; }" % (ra, simm, F(rd), ra)]
    if op == 54: return ["ppc_wrf64(%s, %s);" % (EA, F(rd))]
    if op == 55: return ["{ uint32_t ea = R(%d) + (%d); ppc_wrf64(ea, %s); R(%d) = ea; }" % (ra, simm, F(rd), ra)]
    # paired single load/store
    if op in (56, 57, 60, 61):
        W, I, d = (w >> 15) & 1, (w >> 12) & 7, sx(w & 0xFFF, 12)
        fn = "ppc_psq_l" if op in (56, 57) else "ppc_psq_st"
        if op in (56, 60):
            return ["%s(c, %d, (%s + (%d)), %d, %d);" % (fn, rd, RA0, d, W, I)]
        return ["{ uint32_t ea = R(%d) + (%d); %s(c, %d, ea, %d, %d); R(%d) = ea; }" % (ra, d, fn, rd, W, I, ra)]
    if op == 11: return ["ppc_cmp_s(c, %d, (int32_t)R(%d), %d);" % (crf, ra, simm)]
    if op == 10: return ["ppc_cmp_u(c, %d, R(%d), %du);" % (crf, ra, uimm)]
    # ---- branches ----
    if op == 18:
        li = sx(w & 0x03FFFFFC, 26)
        t = li & 0xFFFFFFFF if w & 2 else (a + li) & 0xFFFFFFFF
        if w & 1: return ["c->lr = 0x%08Xu;" % (a + 4), call(t)]
        if local(t): return (["PPC_POLL(c);"] if t <= a else []) + ["goto L_%08X;" % t]
        return [call(t), "return;"]
    if op == 16:
        d = sx(w & 0xFFFC, 16)
        t = d & 0xFFFFFFFF if w & 2 else (a + d) & 0xFFFFFFFF
        pre, cond = branch_cond(w)
        if w & 1:
            if t == a + 4 and ((w >> 21) & 31) == 20: return ["c->lr = 0x%08Xu;" % (a + 4)]
            body = "c->lr = 0x%08Xu; %s" % (a + 4, call(t))
            return pre + (["if (%s) { %s }" % (cond, body)] if cond else [body])
        if local(t):
            if t <= a:
                return pre + (["if (%s) { PPC_POLL(c); goto L_%08X; }" % (cond, t)] if cond else ["PPC_POLL(c); goto L_%08X;" % t])
            return pre + (["if (%s) goto L_%08X;" % (cond, t)] if cond else ["goto L_%08X;" % t])
        body = "%s return;" % call(t)
        return pre + (["if (%s) { %s }" % (cond, body)] if cond else [body])
    if op == 19:
        xo = (w >> 1) & 0x3FF
        if xo == 16 and not (w & 1):
            pre, cond = branch_cond(w)
            return pre + (["if (%s) return;" % cond] if cond else ["return;"])
        if xo == 16 and (w & 1):   # blrl: chama o endereco em LR
            pre, cond = branch_cond(w)
            body = "{ uint32_t t = c->lr; c->lr = 0x%08Xu; ppc_call_indirect(c, t); }" % (a + 4)
            return pre + (["if (%s) %s" % (cond, body)] if cond else [body])
        if xo == 528 and ((w >> 21) & 31) == 20:
            if w & 1: return ["c->lr = 0x%08Xu;" % (a + 4), "ppc_call_indirect(c, c->ctr);"]
            return ["/* bctr: se for jump table, precisa de anotacao */", "ppc_call_indirect(c, c->ctr);", "return;"]
        if xo == 16 and (w & 1):
            pre, cond = branch_cond(w)
            body = "{ uint32_t t = c->lr; c->lr = 0x%08Xu; ppc_call_indirect(c, t); }" % (a + 4)
            return pre + (["if (%s) %s" % (cond, body)] if cond else [body])
        if xo == 50: return ["return; /* rfi: so em handlers de excecao */"]
        if xo == 150: return NOP
        if xo == 512: return NOP  # mcrxr (raro)
        crops = {257: "(a & b)", 129: "(a & ~b)", 289: "(~(a ^ b))", 225: "(~(a & b))",
                 33: "(~(a | b))", 449: "(a | b)", 417: "(a | ~b)", 193: "(a ^ b)"}
        if xo in crops:
            bt, ba, bb = rd, ra, rb
            return ["{ uint32_t a = (c->cr >> %d) & 1, b = (c->cr >> %d) & 1, r = %s & 1; c->cr = (c->cr & ~(1u << %d)) | (r << %d); }"
                    % (31 - ba, 31 - bb, crops[xo], 31 - bt, 31 - bt)]
        if xo == 0:
            return ["c->cr = (c->cr & ~(0xFu << %d)) | (((c->cr >> %d) & 0xF) << %d);" % (28 - 4 * crf, 28 - 4 * ra // 4 * 4 if False else 28 - 4 * (ra >> 2), 28 - 4 * crf)]
        return None
    # ---- paired singles (op 4) ----
    if op == 4:
        x10, x5 = (w >> 1) & 0x3FF, (w >> 1) & 0x1F
        x6 = (w >> 1) & 0x3F
        if x6 in (6, 7, 38, 39):
            W, I = (w >> 10) & 1, (w >> 7) & 7
            fn = "ppc_psq_l" if x6 in (6, 38) else "ppc_psq_st"
            if x6 in (6, 7): return ["%s(c, %d, %s, %d, %d);" % (fn, rd, EAX, W, I)]
            return ["{ uint32_t ea = R(%d) + R(%d); %s(c, %d, ea, %d, %d); R(%d) = ea; }" % (ra, rb, fn, rd, W, I, ra)]
        d_, a_, b_, c_ = rd, ra, rb, rc_
        def two(e0, e1):
            return ["{ double t0 = %s, t1 = %s; %s = (double)(float)t0; %s = (double)(float)t1; }" % (e0, e1, F(d_), P(d_))]
        if x10 in (0, 32): return ["ppc_fcmp(c, %d, %s, %s);" % (crf, F(a_), F(b_))]
        if x10 in (64, 96): return ["ppc_fcmp(c, %d, %s, %s);" % (crf, P(a_), P(b_))]
        if x10 == 72:  return ["%s = %s; %s = %s;" % (F(d_), F(b_), P(d_), P(b_))]
        if x10 == 40:  return ["%s = -%s; %s = -%s;" % (F(d_), F(b_), P(d_), P(b_))]
        if x10 == 264: return ["%s = fabs(%s); %s = fabs(%s);" % (F(d_), F(b_), P(d_), P(b_))]
        if x10 == 136: return ["%s = -fabs(%s); %s = -fabs(%s);" % (F(d_), F(b_), P(d_), P(b_))]
        merges = {528: (F(a_), F(b_)), 560: (F(a_), P(b_)), 592: (P(a_), F(b_)), 624: (P(a_), P(b_))}
        if x10 in merges:
            e0, e1 = merges[x10]
            return ["{ double t0 = %s, t1 = %s; %s = t0; %s = t1; }" % (e0, e1, F(d_), P(d_))]
        if x10 == 1014: return ["{ uint32_t ea = (%s + R(%d)) & ~31u; for (int i = 0; i < 8; i++) ppc_wr32(ea + 4 * i, 0); }" % (RA0, rb)]
        ops5 = {
            21: ("%s + %s" % (F(a_), F(b_)), "%s + %s" % (P(a_), P(b_))),
            20: ("%s - %s" % (F(a_), F(b_)), "%s - %s" % (P(a_), P(b_))),
            18: ("%s / %s" % (F(a_), F(b_)), "%s / %s" % (P(a_), P(b_))),
            25: ("%s * %s" % (F(a_), F(c_)), "%s * %s" % (P(a_), P(c_))),
            29: ("%s * %s + %s" % (F(a_), F(c_), F(b_)), "%s * %s + %s" % (P(a_), P(c_), P(b_))),
            28: ("%s * %s - %s" % (F(a_), F(c_), F(b_)), "%s * %s - %s" % (P(a_), P(c_), P(b_))),
            31: ("-(%s * %s + %s)" % (F(a_), F(c_), F(b_)), "-(%s * %s + %s)" % (P(a_), P(c_), P(b_))),
            30: ("-(%s * %s - %s)" % (F(a_), F(c_), F(b_)), "-(%s * %s - %s)" % (P(a_), P(c_), P(b_))),
            12: ("%s * %s" % (F(a_), F(c_)), "%s * %s" % (P(a_), F(c_))),
            13: ("%s * %s" % (F(a_), P(c_)), "%s * %s" % (P(a_), P(c_))),
            14: ("%s * %s + %s" % (F(a_), F(c_), F(b_)), "%s * %s + %s" % (P(a_), F(c_), P(b_))),
            15: ("%s * %s + %s" % (F(a_), P(c_), F(b_)), "%s * %s + %s" % (P(a_), P(c_), P(b_))),
            10: ("%s + %s" % (F(a_), P(b_)), P(c_)),
            11: (F(c_), "%s + %s" % (F(a_), P(b_))),
            24: ("1.0 / %s" % F(b_), "1.0 / %s" % P(b_)),
            26: ("1.0 / sqrt(%s)" % F(b_), "1.0 / sqrt(%s)" % P(b_)),
            23: ("(%s >= 0.0 ? %s : %s)" % (F(a_), F(c_), F(b_)), "(%s >= 0.0 ? %s : %s)" % (P(a_), P(c_), P(b_))),
        }
        if x5 in ops5: return two(*ops5[x5])
        return None
    # ---- float single (59) e double (63) ----
    if op == 59:
        x5 = (w >> 1) & 0x1F; a_, b_, c_ = F(ra), F(rb), F(rc_)
        e = {18: "%s / %s" % (a_, b_), 20: "%s - %s" % (a_, b_), 21: "%s + %s" % (a_, b_),
             22: "sqrt(%s)" % b_, 24: "1.0 / %s" % b_, 25: "%s * %s" % (a_, c_),
             26: "1.0 / sqrt(%s)" % b_, 28: "%s * %s - %s" % (a_, c_, b_), 29: "%s * %s + %s" % (a_, c_, b_),
             30: "-(%s * %s - %s)" % (a_, c_, b_), 31: "-(%s * %s + %s)" % (a_, c_, b_)}.get(x5)
        return ["%s = (double)(float)(%s);" % (F(rd), e)] if e else None
    if op == 63:
        x10, x5 = (w >> 1) & 0x3FF, (w >> 1) & 0x1F
        a_, b_, c_ = F(ra), F(rb), F(rc_)
        if x10 == 0 or x10 == 32: return ["ppc_fcmp(c, %d, %s, %s);" % (crf, a_, b_)]
        if x10 == 12:  return ["%s = (double)(float)%s;" % (F(rd), b_)]
        if x10 == 14:  return ["%s = ppc_fctiw(%s);" % (F(rd), b_)]
        if x10 == 15:  return ["%s = ppc_fctiwz(%s);" % (F(rd), b_)]
        if x10 == 40:  return ["%s = -%s;" % (F(rd), b_)]
        if x10 == 72:  return ["%s = %s;" % (F(rd), b_)]
        if x10 == 264: return ["%s = fabs(%s);" % (F(rd), b_)]
        if x10 == 136: return ["%s = -fabs(%s);" % (F(rd), b_)]
        if x10 == 583: return ["%s = 0.0; /* mffs: FPSCR nao modelado */" % F(rd)]
        if x10 in (711, 70, 38, 134): return NOP
        e = {18: "%s / %s" % (a_, b_), 20: "%s - %s" % (a_, b_), 21: "%s + %s" % (a_, b_),
             22: "sqrt(%s)" % b_, 23: "(%s >= 0.0 ? %s : %s)" % (a_, c_, b_), 25: "%s * %s" % (a_, c_),
             26: "1.0 / sqrt(%s)" % b_, 28: "%s * %s - %s" % (a_, c_, b_), 29: "%s * %s + %s" % (a_, c_, b_),
             30: "-(%s * %s - %s)" % (a_, c_, b_), 31: "-(%s * %s + %s)" % (a_, c_, b_)}.get(x5)
        return ["%s = %s;" % (F(rd), e)] if e else None
    # ---- grupo 31 ----
    if op == 31:
        x10 = (w >> 1) & 0x3FF
        xo = x10 if x10 in XO_SET else ((x10 & 0x1FF) if (x10 & 0x200 and (x10 & 0x1FF) in XO_SET) else None)
        if xo is not None:
            r = {266: ["R(%d) = R(%d) + R(%d);" % (rd, ra, rb)],
                 40:  ["R(%d) = R(%d) - R(%d);" % (rd, rb, ra)],
                 235: ["R(%d) = R(%d) * R(%d);" % (rd, ra, rb)],
                 104: ["R(%d) = -R(%d);" % (rd, ra)],
                 10:  ["ppc_adde(c, %d, R(%d), R(%d), 0);" % (rd, ra, rb)],
                 138: ["ppc_adde(c, %d, R(%d), R(%d), ppc_ca(c));" % (rd, ra, rb)],
                 202: ["ppc_adde(c, %d, R(%d), 0, ppc_ca(c));" % (rd, ra)],
                 234: ["ppc_adde(c, %d, R(%d), 0xFFFFFFFFu, ppc_ca(c));" % (rd, ra)],
                 8:   ["ppc_adde(c, %d, ~R(%d), R(%d), 1);" % (rd, ra, rb)],
                 136: ["ppc_adde(c, %d, ~R(%d), R(%d), ppc_ca(c));" % (rd, ra, rb)],
                 200: ["ppc_adde(c, %d, ~R(%d), 0, ppc_ca(c));" % (rd, ra)],
                 75:  ["R(%d) = (uint32_t)(((int64_t)(int32_t)R(%d) * (int64_t)(int32_t)R(%d)) >> 32);" % (rd, ra, rb)],
                 11:  ["R(%d) = (uint32_t)(((uint64_t)R(%d) * (uint64_t)R(%d)) >> 32);" % (rd, ra, rb)],
                 491: ["R(%d) = ppc_divw((int32_t)R(%d), (int32_t)R(%d));" % (rd, ra, rb)],
                 459: ["R(%d) = ppc_divwu(R(%d), R(%d));" % (rd, ra, rb)]}[xo]
            return r + cr0(rd)
        lg = {444: "R(%d) | R(%d)", 28: "R(%d) & R(%d)", 316: "R(%d) ^ R(%d)", 60: "R(%d) & ~R(%d)",
              124: "~(R(%d) | R(%d))", 412: "R(%d) | ~R(%d)", 284: "~(R(%d) ^ R(%d))", 476: "~(R(%d) & R(%d))"}
        if x10 in lg: return ["R(%d) = %s;" % (ra, lg[x10] % (rd, rb))] + cr0(ra)
        if x10 == 24:  return ["R(%d) = (R(%d) & 0x20) ? 0 : (R(%d) << (R(%d) & 31));" % (ra, rb, rd, rb)] + cr0(ra)
        if x10 == 536: return ["R(%d) = (R(%d) & 0x20) ? 0 : (R(%d) >> (R(%d) & 31));" % (ra, rb, rd, rb)] + cr0(ra)
        if x10 == 792: return ["{ int32_t v = (int32_t)R(%d); int s = R(%d) & 63; int32_t r = s > 31 ? (v >> 31) : (v >> s); ppc_set_ca(c, v < 0 && (s > 31 ? 1 : (v & ((1 << s) - 1)) != 0 && s)); R(%d) = (uint32_t)r; }" % (rd, rb, ra)] + cr0(ra)
        if x10 == 824: return ["{ int32_t v = (int32_t)R(%d); ppc_set_ca(c, v < 0 && %d && (v & ((1 << %d) - 1))); R(%d) = (uint32_t)(v >> %d); }" % (rd, rb, rb, ra, rb)] + cr0(ra)
        if x10 == 954: return ["R(%d) = (uint32_t)(int32_t)(int8_t)R(%d);" % (ra, rd)] + cr0(ra)
        if x10 == 922: return ["R(%d) = (uint32_t)(int32_t)(int16_t)R(%d);" % (ra, rd)] + cr0(ra)
        if x10 == 26:  return ["R(%d) = R(%d) ? (uint32_t)__builtin_clz(R(%d)) : 32;" % (ra, rd, rd)] + cr0(ra)
        ld = {23: "ppc_rd32(%s)", 87: "ppc_rd8(%s)", 279: "ppc_rd16(%s)", 343: "(uint32_t)(int32_t)(int16_t)ppc_rd16(%s)",
              534: "__builtin_bswap32(ppc_rd32(%s))", 790: "(uint32_t)__builtin_bswap16((uint16_t)ppc_rd16(%s))"}
        if x10 in ld: return ["R(%d) = %s;" % (rd, ld[x10] % EAX)]
        st = {151: "ppc_wr32(%s, R(%d));", 215: "ppc_wr8(%s, R(%d));", 407: "ppc_wr16(%s, R(%d));",
              662: "ppc_wr32(%s, __builtin_bswap32(R(%d)));", 918: "ppc_wr16(%s, __builtin_bswap16((uint16_t)R(%d)));"}
        if x10 in st: return [st[x10] % (EAX, rd)]
        ldu = {55: "ppc_rd32", 119: "ppc_rd8"}
        if x10 in ldu: return ["R(%d) = R(%d) + R(%d);" % (ra, ra, rb), "R(%d) = %s(R(%d));" % (rd, ldu[x10], ra)]
        stu = {183: "ppc_wr32", 247: "ppc_wr8", 439: "ppc_wr16"}
        if x10 in stu: return ["{ uint32_t ea = R(%d) + R(%d); %s(ea, R(%d)); R(%d) = ea; }" % (ra, rb, stu[x10], rd, ra)]
        fl = {535: "%s = ppc_rdf32(%s); %s = %s;", 599: "%s = ppc_rdf64(%s);"}
        if x10 == 535: return ["%s = ppc_rdf32(%s); %s = %s;" % (F(rd), EAX, P(rd), F(rd))]
        if x10 == 599: return ["%s = ppc_rdf64(%s);" % (F(rd), EAX)]
        if x10 == 663: return ["ppc_wrf32(%s, (float)%s);" % (EAX, F(rd))]
        if x10 == 727: return ["ppc_wrf64(%s, %s);" % (EAX, F(rd))]
        if x10 == 983: return ["ppc_wr32(%s, ppc_dbl_lo(%s));" % (EAX, F(rd))]
        if x10 == 0:   return ["ppc_cmp_s(c, %d, (int32_t)R(%d), (int32_t)R(%d));" % (crf, ra, rb)]
        if x10 == 32:  return ["ppc_cmp_u(c, %d, R(%d), R(%d));" % (crf, ra, rb)]
        if x10 == 19:  return ["R(%d) = c->cr;" % rd]
        if x10 == 512: return ["ppc_setcr_raw(c, %d, c->xer >> 28); c->xer &= 0x0FFFFFFFu;" % crf]
        if x10 == 144:
            crm = (w >> 12) & 0xFF
            m = 0
            for i in range(8):
                if crm & (0x80 >> i): m |= 0xF << (28 - 4 * i)
            return ["c->cr = (c->cr & 0x%08Xu) | (R(%d) & 0x%08Xu);" % (~m & 0xFFFFFFFF, rd, m)]
        if x10 == 83:  return ["R(%d) = c->msr;" % rd]
        if x10 == 146: return ["c->msr = R(%d);" % rd]
        if x10 in (339, 467):
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            reg = {8: "c->lr", 9: "c->ctr", 1: "c->xer"}.get(spr, "c->spr[%d]" % spr)
            return ["R(%d) = %s;" % (rd, reg)] if x10 == 339 else ["%s = R(%d);" % (reg, rd)]
        if x10 == 371:
            spr = ((w >> 16) & 31) | (((w >> 11) & 31) << 5)
            return ["R(%d) = (uint32_t)(ppc_timebase() %s);" % (rd, ">> 32" if spr == 269 else "")]
        if x10 == 1014: return ["{ uint32_t ea = %s & ~31u; for (int i = 0; i < 8; i++) ppc_wr32(ea + 4 * i, 0); }" % EAX]
        if x10 in (86, 54, 278, 246, 470, 982, 598, 854, 4, 306, 370, 210, 595, 467 + 1000):
            return NOP   # cache/sync/trap/tlb/sr: sem efeito no recomp
        return None
    return None

def falls_through(w):
    """True se a execucao pode continuar na instrucao seguinte (nao e b/blr/bctr incondicional sem link)."""
    op = w >> 26
    if op == 18: return bool(w & 1)                      # b/ba: so cai adiante se for bl
    if op == 19:
        xo = (w >> 1) & 0x3FF
        if xo == 50: return False                        # rfi
        if xo in (16, 528):                              # bclr / bcctr
            uncond = ((w >> 21) & 0x14) == 0x14
            return not uncond or bool(w & 1)
    return True

FALLTHROUGH_FIXED = [0]

def emit_fn(dol, f, end, funcs, hooks, stats, trace=False):
    out = ["void f_%08X(PPCContext *c) {" % f]
    if trace: out.append("  ppc_trace(0x%08X);" % f)
    for a in range(f, end, 4):
        w = dol.word(a)
        out.append("L_%08X:;" % a)
        lines = lift(a, w, f, end, funcs, hooks)
        if lines is None:
            lines = ["ppc_unimpl(c, 0x%08X, 0x%08X); return;" % (a, w)]
            op = w >> 26
            key = (op, (w >> 1) & 0x3FF) if op in (31, 19, 59, 63, 4) else (op,)
            stats[key] += 1
        out += ["  " + l for l in lines]
    # Funcoes descobertas podem terminar sem terminador (o codigo cai na funcao seguinte,
    # ex.: blocos de um mesmo corpo separados por ponteiros em tabelas). Sem isto o C
    # retornava ao chamador pulando o epilogo (r31/pilha corrompidos).
    if end > f and falls_through(dol.word(end - 4)):
        if end in funcs and end not in hooks: out.append("  f_%08X(c);" % end)
        else: out.append("  ppc_call_indirect(c, 0x%08X);" % end)
        FALLTHROUGH_FIXED[0] += 1
    out.append("}")
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dol"); ap.add_argument("-o", default="gen"); ap.add_argument("--hooks")
    ap.add_argument("--chunk", type=int, default=300)
    ap.add_argument("--trace", action="store_true", help="registra entrada de funcoes (debug)")
    args = ap.parse_args()
    dol = Dol(open(args.dol, "rb").read())
    hooks, hook_names = set(), {}
    if args.hooks and os.path.exists(args.hooks):
        for l in open(args.hooks):
            l = l.split("#")[0].split()
            if not l: continue
            ad = int(l[0], 16); hooks.add(ad)
            hook_names[ad] = l[1] if len(l) > 1 else "nop_%08X" % ad
    funcs = discover(dol, hooks)
    os.makedirs(args.o, exist_ok=True)
    for fn in os.listdir(args.o):
        if fn.endswith((".c", ".h")): os.remove(os.path.join(args.o, fn))
    addrs = sorted(funcs)
    stats = collections.Counter()
    with open(os.path.join(args.o, "recomp_funcs.h"), "w") as h:
        h.write('#pragma once\n#include "ppc.h"\n')
        for a in addrs: h.write("void f_%08X(PPCContext *c);\n" % a)
    for i in range(0, len(addrs), args.chunk):
        with open(os.path.join(args.o, "recomp_%03d.c" % (i // args.chunk)), "w") as o:
            o.write('#include "recomp_funcs.h"\n\n')
            for a in addrs[i:i + args.chunk]:
                o.write(emit_fn(dol, a, funcs[a], funcs, hooks, stats, args.trace) + "\n\n")
    with open(os.path.join(args.o, "recomp_table.c"), "w") as t:
        t.write('#include "recomp_funcs.h"\nconst PPCFuncEntry g_func_table[] = {\n')
        for a in addrs: t.write("  {0x%08X, f_%08X},\n" % (a, a))
        t.write("  {0, 0}\n};\nconst uint32_t g_func_count = %d;\n" % len(addrs))
    with open(os.path.join(args.o, "hooks_gen.c"), "w") as hg:
        hg.write('#include "ppc.h"\n/* gerado de hooks.txt. Funcoes weak: sobrescreva em runtime/hooks.c */\n')
        for n in sorted(set(hook_names.values())):
            hg.write("__attribute__((weak)) void hook_%s(PPCContext *c) { R(3) = 0; }\n" % n)
        hg.write("void hooks_gen_init(void) {\n")
        for ad, n in sorted(hook_names.items()): hg.write("  ppc_register_hook(0x%08X, hook_%s);\n" % (ad, n))
        hg.write("}\n")
    total = sum((funcs[a] - a) // 4 for a in addrs)
    text_total = sum(n for _, _, n in dol.text) // 4
    print("entry 0x%08X | %d funcoes | %d/%d instrucoes do texto cobertas | %d nao implementadas"
          % (dol.entry, len(addrs), total, text_total, sum(stats.values())))
    print("  funcoes com fall-through para a seguinte (corrigidas): %d" % FALLTHROUGH_FIXED[0])
    for k, v in stats.most_common(15): print("  nao impl:", k, v)

if __name__ == "__main__":
    main()
