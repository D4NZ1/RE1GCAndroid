#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "ppc.h"

static int s_initialized;
JNIEXPORT jint JNICALL
Java_com_example_re1gc_NativeBridge_loadDol(JNIEnv *env, jclass cls, jstring path) {
    (void)cls;
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    if (!p) return -1;
    if (!s_initialized) {
        g_mem = (uint8_t *)calloc(1, PPC_MEM_SIZE);
        if (!g_mem) { (*env)->ReleaseStringUTFChars(env, path, p); return -2; }
        hooks_init();
        s_initialized = 1;
    }
    uint32_t entry = 0;
    int rc = dol_load(p, &entry);
    (*env)->ReleaseStringUTFChars(env, path, p);
    if (rc != 0) return -3;
    return (jint)entry;
}
JNIEXPORT jstring JNICALL
Java_com_example_re1gc_NativeBridge_version(JNIEnv *env, jclass cls) {
    (void)cls;
    return (*env)->NewStringUTF(env, "re1gc Android native loader - experimental; game execution/GX not implemented");
}
JNIEXPORT void JNICALL
Java_com_example_re1gc_NativeBridge_destroy(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    free(g_mem); g_mem = NULL; s_initialized = 0;
}
