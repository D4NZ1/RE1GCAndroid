#!/usr/bin/env python3
"""findgx.py: lista candidatos a funcoes do SDK GX a partir do C gerado (gen/).
Uso: python3 tools/findgx.py [gen_dir]   (nao precisa do main.dol)
Heuristica: funcao que carrega 0xCC010000 e grava em off -32768 = escreve no WGPIPE (0xCC008000)."""
import re, sys, glob, collections
gen = sys.argv[1] if len(sys.argv) > 1 else "gen"
fn_re = re.compile(r"^void f_([0-9A-F]{8})\(PPCContext \*c\) \{", re.M)
rows = []
for path in sorted(glob.glob(gen + "/recomp_[0-9]*.c")):
    src = open(path, errors="replace").read()
    ms = list(fn_re.finditer(src))
    for i, m in enumerate(ms):
        body = src[m.end(): ms[i+1].start() if i+1 < len(ms) else len(src)]
        addr = int(m.group(1), 16)
        n = body.count("\nL_")
        pipe = "0xCC010000u" in body and "(-32768)" in body
        wr = len(re.findall(r"\+ \(-32768\)\), ", body))
        bp = "(97)" in body   # 0x61 = comando BP
        xf = "(16)" in body
        cp = "0xCC000000u" in body
        calls = len(set(re.findall(r"\bf_([0-9A-F]{8})\(c\)", body)))
        rows.append((addr, n, pipe, wr, bp, xf, cp, calls, path.split("/")[-1]))
pipe = [r for r in rows if r[2]]
print("funcoes totais:", len(rows), "| escrevem no WGPIPE:", len(pipe))
hist = collections.Counter(r[0] >> 12 for r in pipe)
print("faixas (4KB) com escritores de FIFO:")
for k in sorted(hist): print("  %08X-: %d" % (k << 12, hist[k]))
print("\nescritores de FIFO (addr, instr, wr_fifo, BP, XF):")
for r in pipe: print("  %08X %4d %3d %s %s" % (r[0], r[1], r[3], "BP" if r[4] else "--", "XF" if r[5] else "--"))
print("\ncandidatos a GXInit (usa 0xCC000000 + muitas instr, faixa 8012xxxx):")
for r in rows:
    if r[6] and r[1] > 150 and 0x80120000 <= r[0] < 0x80140000: print("  %08X %4d" % (r[0], r[1]))
