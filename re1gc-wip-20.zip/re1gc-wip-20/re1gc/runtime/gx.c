/* gx.c: parser do FIFO do GX (WGPIPE). Fase 1: SO REGISTRA/CONTA, nao desenha.
   Objetivo: validar que a decodificacao acompanha o jogo (sem dessincronizar) antes de renderizar.
   RE1_GX=1 imprime um resumo a cada 60 DrawDone (e no timeout/fim). */
#include "ppc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern unsigned long g_gx_bytes;

static uint32_t cp[256];                 /* registradores CP (0x50/0x60 VCD, 0x70/0x80/0x90+fmt VAT) */
static uint32_t bp_last[256];
static unsigned long n_op[256], n_bp[256], n_cp[256], n_xf_region[17];
static unsigned long n_draw, n_verts, n_vbytes, n_dl, n_desync, n_vsize0, n_done;
static uint8_t last_bad; static int enabled = -1;
static uint8_t ring[48]; static unsigned long ring_n;      /* ultimos bytes do FIFO principal */
static char hist[10][72]; static unsigned hist_n;           /* ultimos comandos decodificados */
static void hist_add(const char *f, unsigned a, unsigned b, unsigned c, unsigned d) {
    snprintf(hist[hist_n++ % 10], 72, f, a, b, c, d);
}

typedef struct { int st, need, have; uint8_t cmd, buf[16]; uint32_t vleft; int depth; } P;
enum { S_CMD, S_PAY, S_CNT, S_VERT };

static int csz(int f) { return (f == 0 || f == 1) ? 1 : (f == 2 || f == 3) ? 2 : 4; }
static int colsz(int f) { static const int t[8] = {2, 3, 4, 2, 3, 4, 4, 4}; return t[f & 7]; }
static int nrmsz(int f) { return f == 3 ? 2 : f == 4 ? 4 : 1; }
static int vtx_size(int f) {
    uint32_t lo = cp[0x50], hi = cp[0x60], a = cp[0x70 + f], b = cp[0x80 + f], c = cp[0x90 + f];
    int n = 0, i;
    for (i = 0; i <= 8; i++) if ((lo >> i) & 1) n++;                 /* indices de matriz (1 byte cada) */
    int pos = (lo >> 9) & 3, nrm = (lo >> 11) & 3, c0 = (lo >> 13) & 3, c1 = (lo >> 15) & 3;
    if (pos == 1) n += ((a & 1) ? 3 : 2) * csz((a >> 1) & 7); else if (pos) n += pos - 1;
    if (nrm == 1) n += (((a >> 9) & 1) ? 9 : 3) * nrmsz((a >> 10) & 7);
    else if (nrm) n += (nrm - 1) * ((((a >> 9) & 1) && ((a >> 31) & 1)) ? 3 : 1);
    if (c0 == 1) n += colsz((a >> 14) & 7); else if (c0) n += c0 - 1;
    if (c1 == 1) n += colsz((a >> 18) & 7); else if (c1) n += c1 - 1;
    int tc[8] = {(a >> 21) & 1, b & 1, (b >> 9) & 1, (b >> 18) & 1, (b >> 27) & 1, (c >> 5) & 1, (c >> 14) & 1, (c >> 23) & 1};
    int tf[8] = {(a >> 22) & 7, (b >> 1) & 7, (b >> 10) & 7, (b >> 19) & 7, (b >> 28) & 7, (c >> 6) & 7, (c >> 15) & 7, (c >> 24) & 7};
    for (i = 0; i < 8; i++) {
        int m = (hi >> (2 * i)) & 3;
        if (m == 1) n += (tc[i] ? 2 : 1) * csz(tf[i]); else if (m) n += m - 1;
    }
    return n;
}

static void feed(P *p, uint8_t b);
static void run_dl(uint32_t addr, uint32_t size, int depth) {
    if (depth > 4) return;
    P d; memset(&d, 0, sizeof d); d.depth = depth;
    n_dl++;
    for (uint32_t i = 0; i < size; i++) feed(&d, ppc_rd8(0x80000000u | (addr + i)));
}
static uint32_t be32(const uint8_t *b) { return (uint32_t)b[0] << 24 | b[1] << 16 | b[2] << 8 | b[3]; }

static void done_cmd(P *p) {
    const uint8_t *b = p->buf;
    if (!p->depth) { if (p->cmd == 0x08) hist_add("CP reg=%02X val=%08X", b[0], be32(b + 1), 0, 0);
        else if (p->cmd == 0x10) hist_add("XF hdr=%08X (%u palavras)", be32(b), ((be32(b) >> 16) & 15) + 1, 0, 0);
        else if (p->cmd == 0x61) hist_add("BP %08X", be32(b), 0, 0, 0);
        else hist_add("cmd=%02X", p->cmd, 0, 0, 0); }
    switch (p->cmd) {
    case 0x08: cp[b[0]] = be32(b + 1); n_cp[b[0]]++; break;
    case 0x10: { uint32_t h = be32(b); n_xf_region[((h & 0xFFFF) >> 8) & 15]++; p->st = S_VERT; p->vleft = (((h >> 16) & 15) + 1) * 4; p->cmd = 0x10; return; }
    case 0x40: run_dl(be32(b), be32(b + 4), p->depth + 1); break;
    case 0x61: {
        uint32_t v = be32(b); n_bp[v >> 24]++; bp_last[v >> 24] = v;
        if ((v >> 24) == 0x45 && (v & 2)) { n_done++; ppc_raise_irq(19); }   /* PE_FINISH (DrawDone) */
        else if ((v >> 24) == 0x48) ppc_raise_irq(18);                        /* PE_TOKEN */
        if (enabled && (v >> 24) == 0x45 && (v & 2) && n_done % 60 == 0) gx_dump("60 DrawDone");
        break; }
    default: break;                     /* 0x20..0x38 carga indexada de XF: so consome */
    }
    p->st = S_CMD;
}

static void feed(P *p, uint8_t b) {
    switch (p->st) {
    case S_CMD: {
        n_op[b]++;
        if (b == 0x00 || b == 0x01 || b == 0x44 || b == 0x48) return;
        p->cmd = b; p->have = 0;
        if (b == 0x08) p->need = 5; else if (b == 0x10) p->need = 4;
        else if (b == 0x20 || b == 0x28 || b == 0x30 || b == 0x38) p->need = 4;
        else if (b == 0x40) p->need = 8; else if (b == 0x61) p->need = 4;
        else if (b >= 0x80 && (b & 0x78) != 0x08 && b < 0xC0) { p->need = 2; p->st = S_CNT; return; }
        else {
            if (!n_desync && enabled) {
                fprintf(stderr, "[gx!] PRIMEIRO DESYNC: opcode=0x%02X byte#%lu profundidade=%d\n[gx!] ultimos bytes:", b, g_gx_bytes, p->depth);
                for (unsigned k = 0; k < 48 && k < ring_n; k++) fprintf(stderr, "%s%02X", k % 16 ? " " : "\n   ", ring[(ring_n - (ring_n < 48 ? ring_n : 48) + k) % 48]);
                fprintf(stderr, "\n[gx!] ultimos comandos (antigo -> novo):\n");
                for (unsigned k = 0; k < 10 && k < hist_n; k++) fprintf(stderr, "   %s\n", hist[(hist_n - (hist_n < 10 ? hist_n : 10) + k) % 10]);
            }
            n_desync++; last_bad = b; return; }   /* opcode desconhecido: provavel dessincronizacao */
        p->st = S_PAY; return; }
    case S_PAY:
        p->buf[p->have++] = b; if (p->have == p->need) done_cmd(p); return;
    case S_CNT:
        p->buf[p->have++] = b;
        if (p->have == 2) {
            uint32_t cnt = (uint32_t)p->buf[0] << 8 | p->buf[1]; int sz = vtx_size(p->cmd & 7);
            if (!p->depth) hist_add("DRAW %02X n=%u vsize=%d vcd=%08X", p->cmd, cnt, sz, cp[0x50]);
            if (enabled && n_draw < 12 && !p->depth) fprintf(stderr, "[gx] draw %02X n=%u vsize=%d VCD=%08X/%08X VAT=%08X/%08X/%08X\n", p->cmd, cnt, sz, cp[0x50], cp[0x60], cp[0x70 + (p->cmd & 7)], cp[0x80 + (p->cmd & 7)], cp[0x90 + (p->cmd & 7)]);
            n_draw++; n_verts += cnt; if (!sz && cnt) n_vsize0++;
            p->vleft = cnt * (uint32_t)sz; n_vbytes += p->vleft; p->st = p->vleft ? S_VERT : S_CMD;
        } return;
    case S_VERT:
        if (--p->vleft == 0) p->st = S_CMD; return;
    }
}

static P s_main;
void gx_pipe(uint32_t v, int bytes) {
    if (enabled < 0) enabled = getenv("RE1_GX") != NULL;
    g_gx_bytes += bytes;
    for (int i = bytes - 1; i >= 0; i--) { uint8_t by = (uint8_t)(v >> (8 * i)); ring[ring_n++ % 48] = by; feed(&s_main, by); }
}

void gx_dump(const char *why) {
    int i;
    fprintf(stderr, "[gx] (%s) bytes=%lu draws=%lu verts=%lu vbytes=%lu DL=%lu DrawDone=%lu desync=%lu vsize0=%lu",
            why, g_gx_bytes, n_draw, n_verts, n_vbytes, n_dl, n_done, n_desync, n_vsize0);
    if (n_desync) fprintf(stderr, " ultimo_opcode_ruim=0x%02X", last_bad);
    fprintf(stderr, "\n[gx] VCD=%08X/%08X VAT0=%08X/%08X/%08X\n", cp[0x50], cp[0x60], cp[0x70], cp[0x80], cp[0x90]);
    fprintf(stderr, "[gx] BP mais usados:");
    unsigned long t[256]; memcpy(t, n_bp, sizeof t);
    for (int k = 0; k < 6; k++) { int best = -1; for (i = 0; i < 256; i++) if (t[i] && (best < 0 || t[i] > t[best])) best = i;
        if (best < 0) break; fprintf(stderr, " %02X:%lu", best, t[best]); t[best] = 0; }
    fprintf(stderr, "\n");
}
