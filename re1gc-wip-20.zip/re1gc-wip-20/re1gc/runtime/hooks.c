#include <stdlib.h>
#include "ppc.h"
#include <stdio.h>
#include <time.h>
/* Funcoes do SDK (OS, DVD, AX, VI, GX) reimplementadas em C.
   Liste o endereco em hooks.txt para o lifter nao recompilar a original. */

/* VIWaitForRetrace (0x8011D628): no SDK original faz
       en = OSDisableInterrupts(); n = retraceCount;
       do OSSleepThread(&retraceQueue); while (n == retraceCount);
       OSRestoreInterrupts(en);
   retraceCount fica em r13-29904. Aqui nao ha VI nem interrupcoes, entao
   simulamos um VBlank: espera ate o proximo tick de 60 Hz e incrementa o contador. */
#define VI_FRAME_NS (1000000000ull / 60)
extern unsigned long g_gx_bytes;
void hook_VIWaitForRetrace(PPCContext *c) {
    { static int n; if (getenv("RE1_STAT") && (++n % 60 == 0)) fprintf(stderr, "[stat] frames=%d gx_writes=%lu\n", n, g_gx_bytes); }
    static uint64_t next;
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t now = (uint64_t)ts.tv_sec * 1000000000ull + ts.tv_nsec;
    if (!next || now > next + 5 * VI_FRAME_NS) next = now;   /* (re)sincroniza apos atraso longo */
    next += VI_FRAME_NS;
    if (next > now) {
        uint64_t d = next - now;
        ts.tv_sec = d / 1000000000ull; ts.tv_nsec = d % 1000000000ull;
        nanosleep(&ts, NULL);
    }
    uint32_t a = R(13) - 29904;
    ppc_wr32(a, ppc_rd32(a) + 1);
    R(3) = 0;
}

/* __ARChecksize (0x80121070): o SDK testa a ARAM via DMA e le AR_MODE (0xCC005016) esperando
   "init done". Sem DSP/ARAM emulados isso nunca termina. Gravamos o resultado final que a
   original deixaria: 16 MB internos, sem expansao. */
void hook___ARChecksize(PPCContext *c) {
    ppc_wr32(R(13) - 29712, 0x01000000);   /* __AR_InternalSize */
    ppc_wr32(R(13) - 29708, 0);            /* __AR_ExpansionSize */
    ppc_wr32(R(13) - 29716, 0x01000000);   /* __AR_Size (total) */
    ppc_wr32(0x800000D0, 0x01000000);      /* espelho do tamanho da ARAM em low mem */
}

/* OSEnableInterrupts / OSRestoreInterrupts: devolvem o EE anterior; ao habilitar, entregam IRQs pendentes. */
void hook_OSEnableInterrupts(PPCContext *c) {
    uint32_t old = (c->msr >> 15) & 1; c->msr |= 0x8000u; R(3) = old; ppc_deliver_irqs(c); R(3) = old;
}
void hook_OSRestoreInterrupts(PPCContext *c) {
    uint32_t en = R(3), old = (c->msr >> 15) & 1;
    if (en) c->msr |= 0x8000u; else c->msr &= ~0x8000u;
    R(3) = old; if (en) ppc_deliver_irqs(c); R(3) = old;
}

void hooks_init(void) {
    hooks_gen_init();
}

/* DEBUG: loga args de OSAllocFromHeap / OSCreateHeap (remover depois) */
