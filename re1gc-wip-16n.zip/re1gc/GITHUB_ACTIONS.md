# Build APK with GitHub Actions

This repository includes `.github/workflows/android.yml`. GitHub Actions builds the Android debug APK on GitHub-hosted Ubuntu runners, so compiling does not use Termux or the phone's CPU.

## How to use

1. Create or open a GitHub repository.
2. Upload/push the **contents of this `re1gc` folder** to the repository root (the `.github/workflows/android.yml` file must be at the repository root under `.github/workflows/`).
3. On GitHub, open **Actions** and enable workflows if prompted.
4. Run **Android APK** using **Run workflow**, or push a commit to `main`/`master`.
5. Open the completed workflow run, find **Artifacts**, and download `re1gc-debug-apk`.
6. Extract the artifact; it contains `app-debug.apk`.

## Notes

- This workflow uses Java 17, Android SDK platform 35, NDK 27.0.12077973, CMake 3.22.1, and Gradle 8.9.
- The workflow proves only whether the Android project compiles. A successful APK is not proof that the RE1GC runtime can execute the game or render GX graphics.
- Keep copyrighted game ROMs/DOLs out of the GitHub repository. Use only game data you are legally entitled to use.
- The workflow is configured for a debug APK and does not publish a release to Google Play.
