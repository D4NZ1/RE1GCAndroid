# RE1GC Android experimental scaffold

This Android Studio/Gradle project builds the existing C runtime and generated PowerPC-to-C code as an Android native library (`arm64-v8a`, `x86_64`). The first milestone is deliberately limited to selecting and validating a legally extracted `main.dol` using the native DOL loader.

## Build

Open this `android/` directory in Android Studio with Android SDK 35, NDK and CMake 3.22.1 installed, then build the `app` debug variant. Or from this directory run `gradle assembleDebug` if a compatible Gradle installation is available.

## Important status

This is **not a playable port**. The app loads the DOL and displays its entry point; it does not execute the game. The current runtime lacks a correct GameCube OS scheduler/thread context switching and real GX/VI/DVD/AX implementations. Running the entry point before those are implemented would hang or fail. Use only game data extracted from a copy you own; no ROM or game assets are included.
