#pragma once
#include <stdint.h>
#include <string.h>
#include <math.h>

typedef struct PPCContext {
    uint32_t r[32];
    double f[32];   /* ps0 */
    double p1[32];  /* ps1 (paired singles) */
    uint32_t cr, lr, ctr, xer, msr;
    uint32_t spr[1024]; /* GQR0-7 = spr[912..919], HID0/1/2, WPAR, PVR... */
} PPCContext;

typedef void (*ppc_fn)(PPCContext *);
typedef struct { uint32_t addr; ppc_fn fn; } PPCFuncEntry;
extern const PPCFuncEntry g_func_table[];
extern const uint32_t g_func_count;

#define R(n) (c->r[n])
#define PPC_MEM_SIZE (24u * 1024 * 1024)
#define PPC_MEM_MASK 0x01FFFFFFu
extern uint8_t *g_mem;
/* Locked cache (0xE0000000-0xE0003FFF): 16 KB proprios. NAO pode cair na RAM, senao
   mascarar o endereco (0xE0000000 & 0x01FFFFFF = 0) sobrescreve a memoria baixa (0x80000000+). */
extern uint8_t g_lc[16384];
static inline uint8_t *ppc_ptr(uint32_t a) {
    return ((a >> 24) == 0xE0) ? g_lc + (a & 0x3FFF) : g_mem + (a & PPC_MEM_MASK);
}

/* registradores de hardware (0xCC000000: GX FIFO, VI, DSP, DI...) */
uint32_t hw_read32(uint32_t a);
void hw_write32(uint32_t a, uint32_t v);

static inline uint32_t ppc_rd32(uint32_t a) {
    if ((a >> 24) == 0xCC) return hw_read32(a);
    uint32_t v; memcpy(&v, ppc_ptr(a), 4); return __builtin_bswap32(v);
}
static inline uint32_t ppc_rd16(uint32_t a) {
    if ((a >> 24) == 0xCC) return hw_read32(a) & 0xFFFF;
    uint16_t v; memcpy(&v, ppc_ptr(a), 2); return __builtin_bswap16(v);
}
static inline uint32_t ppc_rd8(uint32_t a) {
    if ((a >> 24) == 0xCC) return hw_read32(a) & 0xFF;
    return *ppc_ptr(a);
}
static inline void ppc_wr32(uint32_t a, uint32_t v) {
    if ((a >> 24) == 0xCC) { hw_write32(a, v); return; }
    v = __builtin_bswap32(v); memcpy(ppc_ptr(a), &v, 4);
}
static inline void ppc_wr16(uint32_t a, uint32_t v) {
    if ((a >> 24) == 0xCC) { hw_write32(a, v & 0xFFFF); return; }
    uint16_t x = __builtin_bswap16((uint16_t)v); memcpy(ppc_ptr(a), &x, 2);
}
static inline void ppc_wr8(uint32_t a, uint32_t v) {
    if ((a >> 24) == 0xCC) { hw_write32(a, v & 0xFF); return; }
    *ppc_ptr(a) = (uint8_t)v;
}

static inline float ppc_rdf32(uint32_t a) { uint32_t v = ppc_rd32(a); float f; memcpy(&f, &v, 4); return f; }
static inline void ppc_wrf32(uint32_t a, float f) { uint32_t v; memcpy(&v, &f, 4); ppc_wr32(a, v); }
static inline double ppc_rdf64(uint32_t a) { uint64_t v = ((uint64_t)ppc_rd32(a) << 32) | ppc_rd32(a + 4); double d; memcpy(&d, &v, 8); return d; }
static inline void ppc_wrf64(uint32_t a, double d) { uint64_t v; memcpy(&v, &d, 8); ppc_wr32(a, (uint32_t)(v >> 32)); ppc_wr32(a + 4, (uint32_t)v); }
static inline uint32_t ppc_dbl_lo(double d) { uint64_t v; memcpy(&v, &d, 8); return (uint32_t)v; }
static inline double ppc_int_as_dbl(int32_t i) { uint64_t v = (uint32_t)i; double d; memcpy(&d, &v, 8); return d; }
static inline double ppc_fctiwz(double x) { if (x != x) return ppc_int_as_dbl(INT32_MIN); if (x >= 2147483647.0) return ppc_int_as_dbl(INT32_MAX); if (x <= -2147483648.0) return ppc_int_as_dbl(INT32_MIN); return ppc_int_as_dbl((int32_t)x); }
static inline double ppc_fctiw(double x) { return ppc_fctiwz(rint(x)); }

static inline uint32_t ppc_rotl(uint32_t v, unsigned s) { s &= 31; return s ? (v << s) | (v >> (32 - s)) : v; }

static inline void ppc_setcr(PPCContext *c, int crf, uint32_t bits) {
    int sh = 28 - 4 * crf;
    c->cr = (c->cr & ~(0xFu << sh)) | ((bits | (c->xer >> 31)) << sh);
}
static inline void ppc_cmp_s(PPCContext *c, int crf, int32_t a, int32_t b) { ppc_setcr(c, crf, a < b ? 8 : a > b ? 4 : 2); }
static inline void ppc_cmp_u(PPCContext *c, int crf, uint32_t a, uint32_t b) { ppc_setcr(c, crf, a < b ? 8 : a > b ? 4 : 2); }
static inline void ppc_setcr_raw(PPCContext *c, int crf, uint32_t bits) {
    int sh = 28 - 4 * crf; c->cr = (c->cr & ~(0xFu << sh)) | (bits << sh);
}
static inline void ppc_fcmp(PPCContext *c, int crf, double a, double b) {
    ppc_setcr_raw(c, crf, (a != a || b != b) ? 1 : a < b ? 8 : a > b ? 4 : 2);
}
static inline void ppc_set_ca(PPCContext *c, int ca) { c->xer = (c->xer & ~0x20000000u) | (ca ? 0x20000000u : 0); }
static inline void ppc_adde(PPCContext *c, int d, uint32_t a, uint32_t b, uint32_t cin) {
    uint64_t t = (uint64_t)a + b + cin; c->r[d] = (uint32_t)t; ppc_set_ca(c, (int)(t >> 32));
}
static inline uint32_t ppc_ca(PPCContext *c) { return (c->xer >> 29) & 1; }
static inline uint32_t ppc_divw(int32_t a, int32_t b) { if (!b || (a == INT32_MIN && b == -1)) return 0; return (uint32_t)(a / b); }
static inline uint32_t ppc_divwu(uint32_t a, uint32_t b) { return b ? a / b : 0; }
static inline void ppc_cr0(PPCContext *c, int32_t v) { ppc_cmp_s(c, 0, v, 0); }

void ppc_psq_l(PPCContext *c, int d, uint32_t ea, int w, int i);
void ppc_psq_st(PPCContext *c, int s, uint32_t ea, int w, int i);
uint64_t ppc_timebase(void);
void ppc_trace(uint32_t addr);
void ppc_trace_dump(void);
void ppc_call_indirect(PPCContext *c, uint32_t addr);
void ppc_unimpl(PPCContext *c, uint32_t addr, uint32_t word);
void ppc_register_hook(uint32_t addr, ppc_fn fn);
void hooks_init(void);
void hooks_gen_init(void);
int dol_load(const char *path, uint32_t *entry);

void ppc_deliver_irqs(PPCContext *c);

void hook_SelectThread(PPCContext *c);
void ppc_vi_tick(PPCContext *c);
void ppc_raise_irq(int type);

/* poll de interrupcoes nos saltos para tras (loops de espera): checa o relogio a cada 1024 iteracoes */
extern unsigned g_poll_cnt;
void ppc_poll(PPCContext *c);
#define PPC_POLL(c) do { if ((++g_poll_cnt & 0x3FF) == 0) ppc_poll(c); } while (0)

void ppc_queue_callback(uint32_t cb, uint32_t r3, uint32_t r4);
int dvd_init(const char *root);   /* raiz do disco extraido (sys/ e files/) */
