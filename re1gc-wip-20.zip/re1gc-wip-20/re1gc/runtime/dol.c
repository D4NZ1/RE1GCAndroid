#include "ppc.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static uint32_t be32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

int dol_load(const char *path, uint32_t *entry) {
    if (!path || !entry || !g_mem) return -1;
    FILE *f = fopen(path, "rb");
    if (!f) { perror("[DOL] fopen"); return -1; }

    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return -2; }
    long n = ftell(f);
    if (n < 0x100 || fseek(f, 0, SEEK_SET) != 0) {
        fprintf(stderr, "[DOL] cabecalho invalido ou arquivo muito pequeno\n");
        fclose(f); return -2;
    }

    uint8_t header[0x100];
    if (fread(header, 1, sizeof header, f) != sizeof header) {
        fprintf(stderr, "[DOL] leitura do cabecalho falhou\n");
        fclose(f); return -2;
    }

    /* O BSS do cabecalho deste DOL (0x801D9540 + 0x8AD7C) se sobrepoe a .sdata/.sdata2
       (0x802600E0..0x80263FC0). Entao o BSS tem que ser zerado ANTES de copiar as secoes;
       zerar depois apagava ponteiros estaticos (ex.: ponteiro gx em r13-31224). */
    uint32_t bss = be32(header + 0xD8);
    uint32_t bsz = be32(header + 0xDC);
    uint32_t bphys = bss & PPC_MEM_MASK;
    if (bsz) {
        if ((uint64_t)bphys + bsz > PPC_MEM_SIZE) {
            fprintf(stderr, "[DOL] BSS fora da RAM simulada\n");
            fclose(f); return -6;
        }
        memset(g_mem + bphys, 0, bsz);
    }

    for (int i = 0; i < 18; ++i) {
        uint32_t off = be32(header + i * 4);
        uint32_t addr = be32(header + 0x48 + i * 4);
        uint32_t size = be32(header + 0x90 + i * 4);
        if (!size) continue;

        if ((uint64_t)off + size > (uint64_t)n) {
            fprintf(stderr, "[DOL] secao %d fora do arquivo\n", i);
            fclose(f); return -3;
        }
        /* RAM do GameCube ocupa 0x80000000-0x817FFFFF.
           Mapeamos enderecos pelos 25 bits inferiores, validando a faixa. */
        uint32_t phys = addr & PPC_MEM_MASK;
        if ((uint64_t)phys + size > PPC_MEM_SIZE) {
            fprintf(stderr, "[DOL] secao %d fora da RAM simulada (addr=%08X size=%u)\n", i, addr, size);
            fclose(f); return -4;
        }
        if (fseek(f, (long)off, SEEK_SET) != 0 ||
            fread(g_mem + phys, 1, size, f) != size) {
            fprintf(stderr, "[DOL] leitura da secao %d falhou\n", i);
            fclose(f); return -5;
        }
    }

    *entry = be32(header + 0xE0);
    fclose(f);
    fprintf(stderr, "[DOL] carregado: entry=0x%08X, tamanho=%ld bytes\n", *entry, n);
    return 0;
}
