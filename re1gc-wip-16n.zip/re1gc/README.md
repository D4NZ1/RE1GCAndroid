# re1gc: Resident Evil (GameCube) nativo para Android

Port nativo do **Resident Evil Remake (GameCube)** para Android, por recompilação estática.
Em vez de emular o GameCube (como o Dolphin faz), o código PowerPC do jogo é traduzido para C,
compilado para ARM64 e ligado a um runtime próprio (gráficos, áudio, disco, controles).

Você fornece o seu próprio jogo. Nada do jogo é distribuído neste repositório.

## O que eu pretendo trazer no projeto

- Executável nativo (APK) do RE Remake para Android ARM64, sem depender do Dolphin.
- Mais leve que a emulação: a CPU do GameCube deixa de ser emulada, vira código nativo.
- Gráficos via OpenGL ES / Vulkan (SDL2), reimplementando o GX (a GPU do GameCube).
- Áudio reimplementado (AX/DSP), leitura de arquivos direto do disco extraído ou ISO.
- Controles de toque, suporte a gamepad e opções como resolução interna e tela cheia.
- Build automatizado por GitHub Actions, no mesmo estilo dos outros projetos (crash3, AriaRecomp).

## O que já foi feito (fase 1)

Pipeline completo DOL -> C -> executável, testado com um DOL sintético (sem o jogo):

- `tools/ppclift.py`: lê o `main.dol`, descobre as funções a partir do entry point e gera C.
  Cobre um subconjunto inicial de PPC: aritmética inteira, lógicas, rotate/mask, load/store
  (com update), comparações, branches condicionais, `bl`/`blr`/`bctr`, LR/CTR/XER.
  Instrução que falta vira `ppc_unimpl()` e é contada no log do lifter.
- `runtime/`: contexto PPC (GPR, FPR, CR, LR, CTR, XER), memória de 24 MB big-endian,
  dispatch por endereço, loader de DOL, sistema de hooks e stubs de hardware
  (`hw_write32` é o ponto de entrada do futuro GX FIFO).
- `hooks.txt` + `runtime/hooks.c`: lugar para reimplementar funções do SDK (OS, DVD, AX, VI, GX).
- `tests/smoke.sh` e workflow do GitHub Actions: geram um DOL de teste, rodam o lifter, compilam e conferem o resultado.
- Teste executado: lifter -> gcc -> binário imprimiu o resultado correto (soma, store, `bl`/`blr`).
  O CMake e o smoke.sh ainda não foram executados (sem CMake no ambiente de teste).

Preparação do jogo no celular: o jogo está em `.rvz` (formato do Dolphin). O plano é extrair o
`main.dol` com o `nodtool` no Termux (`cargo install --locked nodtool`, depois
`nodtool extract "<jogo>.rvz" re1_out`; o DOL fica em `re1_out/sys/main.dol`).

## Status atual (wip-6), analisado com o main.dol real do RE Remake (USA)
- Lifter: 6.147 funcoes, 377.318 de 382.864 instrucoes do texto cobertas (98,6%), 0 instrucoes nao implementadas.
- Suporta inteiros, floats, paired singles (psq_l/psq_st com GQR), carry, CR ops, lmw/stmw, SPRs, timebase.
- Descoberta de funcoes: chamadas diretas + prologos + ponteiros em dados (inclui tabelas apos `bctr`).
- O C gerado (~18 MB) compila sem erro e o jogo executa do `__start` ate o init do OS.
- Hooks nomeados: `hooks.txt` com `ENDERECO nome`; o lifter gera `gen/hooks_gen.c` com `hook_<nome>` (weak, no-op que retorna 0).
  Sobrescreva em `runtime/hooks.c`. Ja hookado: `__OSInitAudioSystem` (801121C8).
- Debug: `ppclift.py --trace` registra as ultimas funcoes; `RE1_TIMEOUT=5 ./re1gc main.dol` imprime o trace se travar.
- Onde parou: loop no scheduler/threads do OS (OSDisable/RestoreInterrupts, thread atual em 0x800000D4).
  Context switch do SDK nao funciona recompilado: threads, interrupcoes, alarmes e filas do OS
  precisam ser reimplementados no host (hooks), como se faz com libultra no N64Recomp.

## O que vai ser feito (ordem)

1. **Rodar no DOL real**: passar o `main.dol` do RE Remake no lifter e ver o relatório de
   instruções não implementadas e funções não resolvidas.
2. **Mais instruções PPC**: ponto flutuante e paired singles (`lfs`, `fadds`, `psq_l`...),
   `rlwimi`, `addic` com carry, `divw`, `lmw`/`stmw`, `mtcrf`, etc.
3. **Jump tables**: hoje um `bctr` dentro de função vira tail call; precisa de detecção ou anotação.
4. **Hooks de OS**: OSInit, OSReport, alocação de memória, threads/alarmes, interrupções, relógio.
5. **DVD**: ler arquivos do disco extraído (ou ISO) para o jogo carregar os dados.
6. **VI + GX**: loop de frame (VSync) e decodificação do FIFO de comandos GX, desenhando com
   OpenGL ES via SDL2. Primeiro marco visual: a tela de boot / logos.
7. **Áudio (AX/DSP)** e **controles** (PAD) com toque e gamepad.
8. **Android**: empacotar em APK (NDK + SDL2), reaproveitando o workflow dos outros projetos.
9. Otimização, menu de opções (resolução, tela) e correções por área do jogo.

## Uso atual (desktop/Termux)

    python3 tools/ppclift.py main.dol -o gen --hooks hooks.txt
    cmake -S . -B build && cmake --build build
    ./build/re1gc main.dol

Teste sem o jogo: `sh tests/smoke.sh`

## Estrutura

    tools/ppclift.py        lifter PPC -> C
    tools/make_test_dol.py  gera DOL sintético de teste
    runtime/                contexto PPC, memória, dispatch, loader, hooks, hardware
    gen/                    saída do lifter (placeholder até rodar)
    hooks.txt               endereços de funções do SDK a não recompilar
    tests/smoke.sh          teste ponta a ponta


## wip-5: trabalho desta revisão

- Regerado `gen/` a partir do `main.dol` fornecido (DOL não incluído no pacote).
- Confirmado pelo lifter: entry `0x80003140`, 6.147 funções descobertas, 377.318/382.864 instruções de texto cobertas e zero instruções classificadas como não implementadas.
- Endurecido `runtime/dol.c`: valida cabeçalho, limites de secções e BSS, leituras curtas e erros de ficheiro antes de copiar dados para a RAM simulada.
- A compilação completa local demorou mais do que o limite do ambiente de análise; portanto, esta revisão ainda precisa de validação do workflow GitHub Actions.
- **Não é APK ainda.** O bloqueio maior continua sendo o SDK do GameCube: threads/context switch, DVD, VI/GX e áudio. O stub de hardware atual não desenha o jogo.


## wip-6: o jogo passou dos 3 travamentos de init

Antes: loop infinito no scheduler do OS. Agora o `__start` roda e o OS inicializa ate o init do GX.
Compilar o `gen/` em `-O0` leva ~1 min (em `-O1`, varios minutos): use `-O0` para depurar.

Corrigido nesta revisao:
- **Hook `VIWaitForRetrace` (0x8011D628)**: a causa do loop do "scheduler" era o jogo dormindo em
  `OSSleepThread` esperando o VBlank. O hook simula 1 VBlank a 60 Hz e incrementa o contador (r13-29904).
- **Hook `__ARChecksize` (0x80121070)**: esperava o bit "init done" da ARAM (0xCC005016). Grava 16 MB internos, sem expansao.
- **Bug do timebase** (`ppc_timebase`): a fracao de nanossegundos estava 1000x lenta (`/10000000` em vez de `/10000`),
  entao o tempo so andava em saltos de 1 s.
- **Modelo do Audio Interface** (`hw_read32/hw_write32`): AICR (0xCC006C00) guarda o valor escrito e AISCNT (0xCC006C08)
  conta a 32/48 kHz conforme o bit 1, so com o bit 0 ligado. O `__AI_SRC_INIT` mede esse intervalo.
- **Locked cache** (0xE0000000-0xE0003FFF) agora tem 16 KB proprios (`g_lc`, `ppc_ptr()` em `ppc.h`).
  Antes, `addr & 0x01FFFFFF` fazia 0xE0000000 cair na memoria baixa.

Onde parou (proximo bloqueio):
- `[recomp] chamada para funcao nao recompilada: 0x00000000` logo depois do init do GX.
- Antes disso, a `f_80129A40` (init do GX, chamada por `f_8001B7DC`) escreve em **0x000000F8** (ponteiro NULL + 0xF8).
  Como o mapa plano faz 0x000000F8 e 0x800000F8 serem o mesmo byte, isso sobrescreve o clock do bus.
  Falta descobrir qual ponteiro esta nulo (provavelmente o buffer do FIFO do GX, alocado pelo jogo).
- Dica: sem gdb, use `backtrace()` + `-rdynamic` dentro de um watch em `ppc_wr32` para achar o autor de uma escrita.

Ainda nao validado: CMake e workflow do GitHub Actions (o smoke foi rodado com gcc direto).


## wip-7: compilacao validada e diagnostico de chamada nula

- O projeto completo (`gen/` do DOL real) compilou com CMake + GCC usando `-O0`.
- `RE1_OPT_LEVEL` agora e configuravel pelo CMake (0 a 3); o padrao e `0` para tornar a compilacao das unidades geradas mais pratica. Para testar desempenho: `-DRE1_OPT_LEVEL=1`.
- O runtime agora imprime LR e registradores PPC quando uma chamada indireta nao encontra funcao, e despeja o trace se estiver disponivel.
- Teste com `main.dol`: o loader funciona e a execucao chega a uma chamada indireta nula em `f_8016A05C`, retornando por `LR=0x8016A074`. O ponteiro de callback lido de `r13-28780` (endereco efetivo `0x80261074`) esta zerado. Isso confirma que o proximo bloqueio e a inicializacao de callbacks/threads do SDK, nao a compilacao do lifter.
- Ainda nao e APK nem jogo jogavel. Nao foram implementados o scheduler/threads completo nem GX/VI/DVD/AX.

## wip-7 diagnóstico adicional (24/10/2026)

- `cmake --build build -j2` passou com sucesso neste ambiente.
- Execução com o `main.dol` fornecido confirma que a chamada indireta nula acontece repetidamente com `LR=0x8016A074`.
- Adicionado modo estritamente diagnóstico `RE1_NULL_CALL=skip`: ignora callbacks nulos para permitir observar o próximo bloqueio. **Não é uma correção semântica** e não está ativado por padrão.
- Com esse modo, o jogo passa das chamadas nulas, mas atinge timeout no scheduler/threads; o trace mostra alternância de funções em `0x8012BFxx` e `0x8012BDxx`. Isso reforça que o próximo trabalho deve ser implementar o scheduler do OS corretamente, não ignorar callbacks indefinidamente.
- `ppc_call_indirect` agora registra alvos no trace circular, melhorando o diagnóstico de chamadas indiretas.

## wip-8: scaffold Android NDK (24/10/2026)

- Added `android/` Gradle application scaffold, Java file picker, JNI bridge, and native shared-library CMake target.
- The app accepts a user-selected `main.dol`, copies it to private app storage, invokes the existing DOL loader, and displays the entry point. It does **not** execute the game or claim playability.
- Android ABIs configured: `arm64-v8a` and `x86_64`; native target compiles the existing generated C sources at `-O0`.
- Android build was not validated here because the Android SDK/NDK/Gradle toolchain is not installed in this environment. Next step: build on Android Studio/CI and fix toolchain issues, then implement OS scheduler/thread switching before game execution.


## wip-9: dois bugs reais achados (loader e lifter) (24/10/2026)

Analise de wip-6/7/8 com o `main.dol` real. Os travamentos de "ponteiro nulo" (GX em wip-6, callback nulo em wip-7) e o `printf` quebrado eram bugs nossos, nao do SDK:

1. **`dol_load` zerava `.sdata`/`.sdata2`.** O BSS do cabecalho deste DOL (0x801D9540 + 0x8AD7C = ate 0x802642BC) se sobrepoe as secoes 13/14 (0x802600E0 e 0x80261140). O BSS era limpo *depois* de copiar as secoes, apagando ponteiros estaticos (ex.: `gx` em r13-31224 = 0x802606E8, que no arquivo vale 0x802319C0 e no runtime lia 0). Agora o BSS e limpo *antes* de copiar as secoes. Com isso as chamadas nulas de wip-7 (`LR=0x8016A074`) sumiram e o init do GX nao escreve mais via NULL.
2. **Lifter nao emitia fall-through entre funcoes.** Funcoes descobertas que terminam sem `b`/`blr`/`bctr` incondicional (167 casos) retornavam ao chamador sem executar o resto do corpo (epilogo, restore de r31/pilha). Sintoma: `r31` corrompido no formatador de `printf` (`f_8013AE2C`) -> chamada para `0x80262101`. Agora `emit_fn` gera `f_<proxima>(c);` no fim (`falls_through()` em `tools/ppclift.py`).

Diagnostico novo:
- `ppc_call_indirect` mostra pilha nativa (backtrace) quando o alvo nao existe (precisa de `-rdynamic`).
- `tools/build_debug.sh`: build incremental `-O0` em paralelo, sem CMake (`sh tools/build_debug.sh`).

Estado apos as correcoes (wip-9): o jogo passa do init do OS, do GX init e do `printf`, entra em codigo do jogo (`f_8001AE10` -> `f_80063990` ...) e fica preso num laco que chama repetidamente `0x80066B9C` via ponteiro de funcao (embrulho de `f_80111F30` com `*(0x80227218)`), ainda sem interrupcoes/alarmes/threads do OS. Proximo passo: identificar `f_80111F30` e o que esse laco espera (provavelmente VBlank/alarme/thread).

Nao validado: build Android, CMake completo e workflow. Instrucoes de lifter: 376.716/382.864 cobertas com os 3 hooks atuais, 0 nao implementadas.


## wip-10: diagnostico do laco de alocacao + HLE do mailbox do DSP (24/10/2026)

- **O laco de `0x80066B9C` nao era falta de heap.** `f_80111F30` = `OSAllocFromHeap`; os pedidos sao pequenos (0xA00, 0x800, 0x280...) e todos retornam enderecos validos (heap 1 tem ~460 KB livres). O trace so mostra chamadas *indiretas*, entao o wrapper de malloc enchia o anel e escondia o travamento real.
- Travamento real: backtrace nativo no SIGALRM (`RE1_BT=1 RE1_TIMEOUT=4 ./build/re1gc main.dol`) mostrou o jogo preso em `f_80122544` (boot task do DSP), esperando o mailbox DSP->CPU (0xCC005004, bit 15).
- **Adicionado HLE do mailbox do DSP** em `runtime/ppc.c`: CPU->DSP consumido na hora; DSP->CPU entrega `0x8071FEED` no boot e `0xDCD10000` apos o ucode iniciar (mail `0x80F3 D001`). O jogo passa dessa espera.
- **Novo bloqueio** (`f_80169DC8` -> laco em `0x80169E5C`): spin em `*(r13-28704)` (= 0x802610C0) ate valer != 0. Quem escreve isso e um callback do DSP/AR chamado por interrupcao. Proximo passo: modelo de interrupcoes (PI/DSP/AR) que chame o handler registrado via `__OSSetInterruptHandler`, ou hook do callback do ARQ/DSP.
- Nao validado: Android, CMake completo, workflow.

## wip-11: interrupcoes do DSP + descoberta de funcoes por lis/addi (24/10/2026)

- **Lifter**: novo `immediate_pointers()` acha enderecos de codigo carregados por `lis`+`addi/ori` (ex.: handler passado a `OSSetInterruptHandler`). Resultado: 6.215 funcoes, 379.705/382.864 instrucoes cobertas (antes 6.147 / 377.318 sem os 3 hooks, ou 376.716 com eles). O handler do DSP (`0x80121F80`) agora existe como funcao.
- **Interrupcoes (HLE)**: hooks `OSEnableInterrupts` (80113790) e `OSRestoreInterrupts` (801137A4). Ao habilitar EE, `ppc_deliver_irqs()` chama o handler de `__OSInterruptTable[7]` (DSP_DSP) quando ha IRQ pendente. A tabela vem de `*(r13-30208)`; o OSContext passado ao handler e falso (0x817F0000).
- **DSP**: `DSP_CONTROL` (0xCC00500A) modela DSP_INT (bit 7, escrever 1 limpa) e a mascara (bit 8). O boot do ucode agora gera mail `0xDCD10000` + IRQ.
- Resultado: o jogo passa do spin em `0x80169E5C`. **Novo bloqueio**: `f_8016960C` espera em `0x801697C4` o byte `r13-28747` voltar a 0, depois de `f_80169464` (submissao de task ao DSP, com callbacks). Exige simular o ciclo da task do DSP (init/resume/done) ou hookar essa camada (DSPAddTask) chamando os callbacks.
- Nao validado: Android, CMake completo, workflow.

## wip-12: ARQ (DMA da ARAM) em HLE (24/10/2026)

- O "wait da task do DSP" de wip-11 era na verdade o **ARQ**: `f_80169464` chama `ARQPostRequest` (`0x80121BC8`: r3=req r4=owner r5=type r6=prio r7=src r8=dst r9=len r10=callback) e espera o callback (`f_801693E4`) decrementar a contagem em `r13-28747`.
- Hook `ARQPostRequest` em `runtime/ppc.c`: ARAM de 16 MB no host, DMA imediato (type 0 = MRAM->ARAM, 1 = ARAM->MRAM), callback enfileirado e chamado por `ppc_deliver_irqs()` quando o jogo habilita EE (`OSRestoreInterrupts`/`OSEnableInterrupts`).
- Resultado: o jogo passa da espera do ARQ. Cobertura do lifter: 379.618/382.864, 0 nao implementadas.
- **Novo bloqueio**: `f_8001F5A0` -> `f_80114890` -> `f_80116DE0` (= `OSSleepThread`: coloca a thread atual (`*(0x800000E4)`) em estado 4 na fila e chama o scheduler `f_801163F8`). Sem scheduler/threads reais, o "sono" retorna na hora e o chamador entra em laco. Proximo passo: implementar threads do OS no host (OSCreateThread/OSResumeThread/OSSleepThread/OSWakeupThread/OSYieldThread) ou rodar cada thread do jogo em uma thread nativa/ucontext com troca cooperativa.
- Nao validado: Android, CMake completo, workflow.

## wip-13: threads do OS, interrupcoes genericas e GX DrawDone (24/10/2026)

- `runtime/threads.c`: hook de `SelectThread` (0x801163F8). Filas, estados e prioridades continuam sendo o codigo original do jogo; so a troca de contexto (OSSaveContext/OSLoadContext) e feita no host com `ucontext` (troca cooperativa). Se nao ha thread pronta, o idle deixa passar 1/60 s e entrega IRQs.
- `ppc_deliver_irqs()` agora e generico: fila de IRQs por tipo (`ppc_raise_irq`), chama o handler de `__OSInterruptTable[tipo]` e preserva o `OSCurrentContext` (0x800000D4). DSP = 7, PE_TOKEN = 18, PE_FINISH = 19, VI = 24.
- WGPIPE (0xCC008000): detecta BP DrawDone (`0x61` + `0x45......`, bit 1) e levanta PE_FINISH. `GXSetDrawDone` ja nao trava.
- Depuracao: `RE1_THR=1` (threads/SelectThread), `RE1_PROF=1` (amostragem de pilha a cada 0,5 s), `RE1_STAT=1`, `RE1_BT=1`.
- **Onde parou**: o jogo esta no laco de quadros (`f_8001B628`, espera em `L_8001B6B8`) aguardando o contador de retrace em `r13-30944`, que so sobe por interrupcao de VI (tipo 24, `__VIRetraceHandler`).
- **Proximo passo (nao aplicado)**: (1) o lifter emitir `PPC_POLL(c)` em saltos para tras (loops de espera nao passam por OSRestoreInterrupts); (2) registradores VI 16 bits (0xCC002000) com DISP_INT0..3 (0x30/0x34/0x38/0x3C: bit 15 pendente, bit 12 habilitado; escrever com bit 15 = 0 limpa); (3) VBlank a 60 Hz levantando a IRQ 24; (4) remover o hook `VIWaitForRetrace` para usar o original com OSSleepThread. Depois: DVD, GX (decodificar FIFO) e audio.
- Nao validado: Android, CMake completo, workflow.


## wip-14: VI/threads validados, jogo roda o laço de quadros (24/10/2026)

Estado verificado com o `main.dol` real (build `-O0`, `tools/build_debug.sh`, ~20 s com 2 núcleos):
- `gen/` regenerado e idêntico ao do wip-13 (6.212 funções, 379.476/382.864 instruções, 0 não implementadas).
- **VBlank/VI funciona**: IRQ 24 a 60 Hz chama `__VIRetraceHandler` (0x8011CCBC), o callback 0x8001B618 incrementa o contador do jogo e `VIWaitForRetrace` original acorda a thread principal (`retraceCount` sobe 1 por quadro). Não é mais preciso o hook antigo de `VIWaitForRetrace`.
- **Threads**: main (0x80230C48) e worker (0x8021ED98, entry 0x8001F574) alternam corretamente via `SelectThread`.
- A thread worker executa um interpretador de stream/cópia longo (`f_80060688` -> `f_80060470`/`f_8006064C`/`f_8006066C`, ~1 M chamadas). Em `-O0` ele ainda não terminou em 20 s: **provável gargalo é velocidade**, não travamento. Próximo teste: build `-O1` (compilar `gen/*.c` com `-O1` leva vários minutos; não concluído) e rodar >60 s.
- Nenhum comando de DVD foi emitido ainda (sem escrita em 0xCC00601C). Quando chegar a hora: o jogo vai precisar de FST/boot info na RAM (0x80000038) e de DVD em HLE. Achados: `DVDReadAsyncPrio` = 0x80119738, `DVDReadPrio` = 0x80119828; código de DVD low-level em 0x80118xxx-0x8011Cxxx. Plano: carregar `sys/fst.bin` de um disco extraído e hookar a leitura absoluta (`DVDReadAbsAsyncPrio`) lendo de `files/`.

Novas ferramentas de depuração (variáveis de ambiente):
- `RE1_HW=1` loga (1x por endereço) acessos a registradores de hardware ainda não modelados.
- `RE1_CALLS=N` (+ `RE1_CALLS_N=M`) imprime M entradas de função após pular N (precisa de `ppclift.py --trace`).
- `RE1_THR=N` janela de `[sel]` do SelectThread a partir da chamada N (agora com estado das duas threads); `RE1_DUMP=N` dump de threads com pilha PPC no idle nº N; `RE1_SW=1` troca de threads.
- `ppc_trace_dump` agora mostra o anel inteiro (256 entradas).

Não validado: CMake completo, workflow do GitHub Actions, build Android.

## wip-14b: DVD em HLE (24/10/2026)

- `runtime/dvd.c`: `./re1gc main.dol <pasta_extraida>` (a pasta do `nodtool extract`, com `sys/fst.bin` e `files/`). Carrega o FST na RAM em 0x817E0000 e grava 0x80000038/0x8000003C como o apploader faria; `hook_DVDReadAbsAsyncPrio` (0x8011B654) le direto de `files/` pelo offset absoluto, marca o bloco como END e entrega o callback pela fila de IRQs (`ppc_queue_callback`, que agora tambem serve ao ARQ).
- Teste com o `fst.bin` real (1.940 arquivos) e um disco falso (arquivos zerados): o jogo passa a **emitir a primeira leitura de DVD** (off=0x0DFD8000, len=0x2DED40 -> 0x81440000). Antes, sem FST, ele nunca pedia nada. `RE1_DVD=1` loga as leituras.
- Nao testado com os dados reais do jogo (so o DOL e o fst.bin foram fornecidos).

## wip-15b: compila no Termux/Android (bionic)
- Threads do OS agora usam pthreads com troca por "bastao" (bionic nao tem `ucontext`); `execinfo.h` so e usado com glibc.
- Termux: `pkg install clang python unzip; ln -sf $PREFIX/bin/clang $PREFIX/bin/gcc; sh tools/build_debug.sh`.
