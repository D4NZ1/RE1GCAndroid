# RE1GC Android experimental scaffold

This Android Studio/Gradle project builds the existing C runtime and generated PowerPC-to-C code as an Android native library (`arm64-v8a`, `x86_64`). The current milestone includes the PPC runtime, generated recompilation units, OS thread scheduler hooks and DVD HLE sources in the Android native library. The Android screen still only selects and validates `main.dol`; game execution remains intentionally disabled until the boot path and GX renderer are implemented and tested.

## Build

Open this `android/` directory in Android Studio with Android SDK 35, NDK and CMake 3.22.1 installed, then build the `app` debug variant. Or from this directory run `gradle assembleDebug` if a compatible Gradle installation is available.

## Important status

This is **not a playable port**. The app loads the DOL and displays its entry point; it does not execute the game. The scheduler/thread and DVD HLE sources are now linked into the Android native library, but they are experimental and not yet validated on device. GX rendering, a verified GameCube boot sequence, and complete VI/AX emulation are still missing. Running the DOL entry point before those are implemented could hang or fail. Use only game data extracted from a copy you own; no ROM or game assets are included.
