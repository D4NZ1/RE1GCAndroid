#!/bin/sh
set -e
cd "$(dirname "$0")/.."
python3 tools/make_test_dol.py /tmp/test.dol
python3 tools/ppclift.py /tmp/test.dol -o gen
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release >/dev/null
cmake --build build -j
./build/re1gc /tmp/test.dol | tee /tmp/out.txt
grep -q "r5=13 mem\[0x80002000\]=12" /tmp/out.txt && echo "SMOKE OK"
