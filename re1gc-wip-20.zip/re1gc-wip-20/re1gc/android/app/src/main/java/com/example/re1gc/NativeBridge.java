package com.example.re1gc;

final class NativeBridge {
    static { System.loadLibrary("re1gc"); }
    static native int loadDol(String path);
    static native String version();
    static native void destroy();
    private NativeBridge() {}
}
