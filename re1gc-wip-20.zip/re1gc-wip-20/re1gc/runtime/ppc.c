#include "ppc.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef __GLIBC__
#include <execinfo.h>
#endif

uint8_t *g_mem;
uint8_t g_lc[16384];
unsigned long g_gx_bytes;
unsigned g_poll_cnt;
#define MAX_HOOKS 1024
static struct { uint32_t addr; ppc_fn fn; } s_hooks[MAX_HOOKS];
static int s_nhooks;

void ppc_register_hook(uint32_t addr, ppc_fn fn) {
    if (s_nhooks < MAX_HOOKS) { s_hooks[s_nhooks].addr = addr; s_hooks[s_nhooks].fn = fn; s_nhooks++; }
}

void ppc_call_indirect(PPCContext *c, uint32_t addr) {
    ppc_trace(addr);
    /* A zero target is normally a bug. Allow an opt-in diagnostic mode to
       skip null callbacks so later initialization failures can be observed. */
    if (addr == 0) {
        const char *mode = getenv("RE1_NULL_CALL");
        if (mode && mode[0] == 's' && mode[1] == 'k' && mode[2] == 'i' && mode[3] == 'p' && mode[4] == '\0') {
            fprintf(stderr, "[recomp] aviso: callback nulo ignorado (RE1_NULL_CALL=skip), LR=0x%08X\n", c->lr);
            c->r[3] = 0;
            return;
        }
    }
    for (int i = 0; i < s_nhooks; i++)
        if (s_hooks[i].addr == addr) { s_hooks[i].fn(c); return; }
    uint32_t lo = 0, hi = g_func_count;
    while (lo < hi) {
        uint32_t mid = (lo + hi) / 2;
        if (g_func_table[mid].addr == addr) { g_func_table[mid].fn(c); return; }
        if (g_func_table[mid].addr < addr) lo = mid + 1; else hi = mid;
    }
    fprintf(stderr, "[recomp] chamada para funcao nao recompilada: 0x%08X\n", addr);
    fprintf(stderr, "[recomp] contexto: LR=0x%08X r1=0x%08X r13=0x%08X r3=0x%08X r4=0x%08X r5=0x%08X r6=0x%08X\n",
            c->lr, c->r[1], c->r[13], c->r[3], c->r[4], c->r[5], c->r[6]);
    fprintf(stderr, "[recomp] investigue a chamada no endereco LR-4 (ou LR, conforme o tipo de branch).\n");
    ppc_trace_dump();
#ifdef __GLIBC__
    { void *bt[32]; int k = backtrace(bt, 32); fprintf(stderr, "[recomp] pilha nativa (precisa de -rdynamic):\n"); backtrace_symbols_fd(bt, k, 2); }
#endif
    exit(2);
}

void ppc_unimpl(PPCContext *c, uint32_t addr, uint32_t word) {
    fprintf(stderr, "[recomp] instrucao nao implementada em 0x%08X: 0x%08X\n", addr, word);
    exit(3);
}

/* --- hardware: stubs, aqui entra o GX/VI/DSP depois --- */
uint64_t ppc_timebase(void);

/* --- Audio Interface (AI): AICR em 0xCC006C00, AISCNT em 0xCC006C08 ---
   O contador de amostras avanca na taxa escolhida pelo bit 1 do AICR (0=32 kHz, 1=48 kHz)
   e so enquanto o bit 0 (PSTAT/play) esta ligado. __AI_SRC_INIT mede o intervalo entre
   mudancas do AISCNT e exige que ele caia numa janela de tempo. */
static uint32_t s_ai_cr;
static uint64_t s_ai_last;
static double   s_ai_cnt;
static void ai_update(void) {
    uint64_t now = ppc_timebase();
    if (s_ai_last && (s_ai_cr & 1)) {
        double rate = (s_ai_cr & 2) ? 48000.0 : 32000.0;
        s_ai_cnt += (double)(now - s_ai_last) * rate / 40500000.0;
    }
    s_ai_last = now;
}


/* ---- DSP mailbox HLE (0xCC005000): sem DSP real. CPU->DSP e consumido na hora;
   DSP->CPU e uma fila preenchida por esta HLE (0x8071FEED no boot, 0xDCD10000 apos o boot do ucode). ---- */
static uint32_t s_dsp_q[32]; static int s_dsp_h, s_dsp_t, s_dsp_init;
static uint16_t s_dsp_to_hi, s_dsp_ctl; static int s_dsp_irq;
static void dsp_push(uint32_t m) { s_dsp_q[s_dsp_t++ & 31] = m; }
static void dsp_init_once(void) { if (!s_dsp_init) { s_dsp_init = 1; dsp_push(0x8071FEED); } }
static int dsp_read(uint32_t a, uint32_t *out) {
    switch (a & ~1u) {
    case 0xCC005000: *out = s_dsp_to_hi & 0x7FFF; return 1;                 /* bit15 = pendente: sempre limpo */
    case 0xCC005002: *out = 0; return 1;
    case 0xCC005004: dsp_init_once(); *out = (s_dsp_h != s_dsp_t) ? (0x8000 | (s_dsp_q[s_dsp_h & 31] >> 16)) : 0; return 1;
    case 0xCC005006: dsp_init_once(); *out = (s_dsp_h != s_dsp_t) ? (s_dsp_q[s_dsp_h++ & 31] & 0xFFFF) : 0; return 1;
    case 0xCC00500A: *out = (s_dsp_ctl & ~0x0081u) | (s_dsp_irq ? 0x0080 : 0); return 1;   /* bit7 = DSP_INT */                 /* RESET limpo; sem IRQ pendente */
    }
    return 0;
}
static int dsp_write(uint32_t a, uint32_t v) {
    switch (a & ~1u) {
    case 0xCC005000: s_dsp_to_hi = v; return 1;
    case 0xCC005002:
        if (s_dsp_to_hi == 0x80F3 && v == 0xD001) { dsp_push(0xDCD10000); s_dsp_irq = 1; }       /* fim do boot do ucode -> DSP avisa */
        return 1;
    case 0xCC00500A: if (v & 0x80) s_dsp_irq = 0; s_dsp_ctl = v & ~0x00A8u; return 1;   /* escrever 1 limpa DSP_INT */
    }
    return 0;
}

static uint32_t s_irq_pend;
void ppc_raise_irq(int type) { s_irq_pend |= 1u << type; }
static void s_irq_pend_vi(void) { s_irq_pend |= 1u << 24; }   /* PI_VI */
/* ---- VI (0xCC002000): registros de 16 bits. DISP_INT0..3 (0x30,0x34,0x38,0x3C): bit 15 = pendente, bit 12 = habilitado ---- */
static uint16_t s_vi[0x80]; static int s_vi_pend;
static int vi_read(uint32_t a, uint32_t *o) {
    uint32_t off = a & 0xFF; if ((a & ~0xFFu) != 0xCC002000 || off >= 0x100) return 0;
    uint16_t v = s_vi[off >> 1];
    if ((off == 0x30 || off == 0x34 || off == 0x38 || off == 0x3C) && s_vi_pend && (v & 0x1000)) v |= 0x8000;
    *o = v; return 1;
}
static int vi_write(uint32_t a, uint32_t v) {
    uint32_t off = a & 0xFF; if ((a & ~0xFFu) != 0xCC002000 || off >= 0x100) return 0;
    if (off == 0x30 || off == 0x34 || off == 0x38 || off == 0x3C) { if (!(v & 0x8000)) s_vi_pend = 0; v &= 0x7FFF; }
    s_vi[off >> 1] = (uint16_t)v; return 1;
}
static uint64_t now_ns(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (uint64_t)ts.tv_sec * 1000000000ull + ts.tv_nsec; }
static void vblank_check(void) {
    static uint64_t next;
    uint64_t now = now_ns();
    if (!next || now > next + 5 * 16666667ull) next = now;
    if (now >= next) { next += 16666667ull; s_vi_pend = 1; s_irq_pend_vi(); }
}

/* RE1_HW=1: loga (uma vez por endereco/tipo) acessos a registradores de hardware ainda nao modelados */
static void hw_log(const char *k, uint32_t a, uint32_t v) {
    static uint32_t seen[512]; static int n, en = -1;
    if (en < 0) en = getenv("RE1_HW") != NULL;
    if (!en) return;
    uint32_t key = (a & ~3u) ^ (k[0] == 'W' ? 1u : 0);
    for (int i = 0; i < n; i++) if (seen[i] == key) return;
    if (n < 512) seen[n++] = key;
    fprintf(stderr, "[hw] %s %08X = %08X\n", k, a, v);
}
uint32_t hw_read32(uint32_t a) {
    { uint32_t o; if (vi_read(a, &o)) return o; }
    { uint32_t o; if ((a & ~15u) == 0xCC005000 && dsp_read(a, &o)) return o; }
    switch (a & ~3u) {
    case 0xCC006C00: return s_ai_cr;
    case 0xCC006C08: ai_update(); return (uint32_t)s_ai_cnt;
    default: hw_log("R", a, 0); return 0;
    }
}
void hw_write32(uint32_t a, uint32_t v) {
    if (vi_write(a, v)) return;
    if ((a & ~15u) == 0xCC005000 && dsp_write(a, v)) return;
    if ((a & ~0xFFFu) == 0xCC008000) { gx_pipe(v, 4); return; }   /* WGPIPE: decodificado em runtime/gx.c */
    switch (a & ~3u) {
    case 0xCC006C00: ai_update(); s_ai_cr = v; break;
    default: hw_log("W", a, v); break;
    }
}

uint64_t ppc_timebase(void) { /* 40.5 MHz */
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((uint64_t)ts.tv_sec * 40500000ull) + ((uint64_t)ts.tv_nsec * 405ull / 10000ull);
}

static double deq(uint32_t a, int type, int scale) {
    switch (type) {
    case 4: return ldexp((double)ppc_rd8(a), -scale);
    case 5: return ldexp((double)ppc_rd16(a), -scale);
    case 6: return ldexp((double)(int8_t)ppc_rd8(a), -scale);
    case 7: return ldexp((double)(int16_t)ppc_rd16(a), -scale);
    default: return ppc_rdf32(a);
    }
}
void ppc_psq_l(PPCContext *c, int d, uint32_t ea, int w, int i) {
    uint32_t g = c->spr[912 + i]; int type = (g >> 16) & 7, scale = (g >> 24) & 63; if (scale & 32) scale -= 64;
    int sz = type == 0 ? 4 : (type == 4 || type == 6) ? 1 : 2;
    c->f[d] = deq(ea, type, scale);
    c->p1[d] = w ? 1.0 : deq(ea + sz, type, scale);
}
static void quant(uint32_t a, double v, int type, int scale) {
    double x = ldexp(v, scale); long lo, hi;
    switch (type) {
    case 4: lo = 0; hi = 255; break; case 5: lo = 0; hi = 65535; break;
    case 6: lo = -128; hi = 127; break; case 7: lo = -32768; hi = 32767; break;
    default: ppc_wrf32(a, (float)v); return;
    }
    long q = x != x ? 0 : x < lo ? lo : x > hi ? hi : (long)x;
    if (type == 4 || type == 6) ppc_wr8(a, (uint32_t)q); else ppc_wr16(a, (uint32_t)q);
}
void ppc_psq_st(PPCContext *c, int s, uint32_t ea, int w, int i) {
    uint32_t g = c->spr[912 + i]; int type = (g >> 0) & 7, scale = (g >> 8) & 63; if (scale & 32) scale -= 64;
    int sz = type == 0 ? 4 : (type == 4 || type == 6) ? 1 : 2;
    quant(ea, c->f[s], type, scale);
    if (!w) quant(ea + sz, c->p1[s], type, scale);
}

/* --- trace de debug (lifter --trace): anel com as ultimas funcoes chamadas --- */
#define TR_N 256
static uint32_t s_tr[TR_N]; static unsigned s_tri;
void ppc_trace(uint32_t a) {
    static long skip = -2, left; static unsigned long cnt;
    s_tr[s_tri++ & (TR_N - 1)] = a;
    if (skip == -2) { const char *e = getenv("RE1_CALLS"); skip = e ? atol(e) : -1; left = getenv("RE1_CALLS_N") ? atol(getenv("RE1_CALLS_N")) : 200; }
    if (skip >= 0 && ++cnt > (unsigned long)skip && left > 0) { left--; fprintf(stderr, "[call] %08X\n", a); }
}
void ppc_trace_dump(void) {
    fprintf(stderr, "[trace] ultimas funcoes (da mais antiga p/ a mais recente):\n");
    for (unsigned i = 0; i < TR_N; i++) {
        uint32_t a = s_tr[(s_tri - TR_N + i) & (TR_N - 1)];
        if (a) fprintf(stderr, "  %08X\n", a);
    }
}

/* ---- entrega de interrupcoes (HLE): chamada quando o jogo habilita EE (OSEnable/RestoreInterrupts).
   Emula o __OSDispatchInterrupt: chama o handler registrado em __OSInterruptTable[tipo]. ---- */
#define OS_INTR_DSP_DSP 7
#define IRQ_CTX 0x817F0000u   /* OSContext falso (0x2C8 bytes) passado ao handler */
/* ---- ARQ/ARAM (HLE): ARQPostRequest (0x80121BC8). r3=req r4=owner r5=type(0 MRAM->ARAM,1 ARAM->MRAM)
   r6=prio r7=src r8=dst r9=len r10=callback. O DMA e feito na hora; o callback(req) e entregue depois. ---- */
static uint8_t s_aram[0x1000000];
static struct { uint32_t cb, req, r4; } s_arq_q[64]; static int s_arq_h, s_arq_t;
/* fila de callbacks deferidos (ARQ/DVD): chamados com r3,r4 quando o jogo habilita EE */
void ppc_queue_callback(uint32_t cb, uint32_t r3, uint32_t r4) {
    s_arq_q[s_arq_t & 63].cb = cb; s_arq_q[s_arq_t & 63].req = r3; s_arq_q[s_arq_t & 63].r4 = r4; s_arq_t++;
}
void hook_ARQPostRequest(PPCContext *c) {
    uint32_t req = R(3), type = R(5), src = R(7), dst = R(8), len = R(9), cb = R(10);
    ppc_wr32(req + 0, 0); ppc_wr32(req + 4, R(4)); ppc_wr32(req + 8, type);
    ppc_wr32(req + 16, src); ppc_wr32(req + 20, dst); ppc_wr32(req + 24, len);
    if (!cb) cb = 0x80121A84;                            /* callback padrao do SDK (__ARQCallbackDefault) */
    ppc_wr32(req + 28, cb);
    for (uint32_t i = 0; i < len; i++) {
        if (type == 0) { uint32_t d = (dst + i) & 0xFFFFFF; s_aram[d] = ppc_rd8(src + i); }
        else           { ppc_wr8(dst + i, s_aram[(src + i) & 0xFFFFFF]); }
    }
    ppc_queue_callback(cb, req, 0);
    R(3) = 0;
}
void ppc_poll(PPCContext *c) { ppc_deliver_irqs(c); }
void ppc_deliver_irqs(PPCContext *c) {
    static int busy;
    vblank_check();
    if (busy || !(c->msr & 0x8000)) return;
    while (s_arq_h != s_arq_t && !busy) {
        uint32_t cb = s_arq_q[s_arq_h & 63].cb, req = s_arq_q[s_arq_h & 63].req, a4 = s_arq_q[s_arq_h & 63].r4; s_arq_h++;
        uint32_t sv_r[32], sv_lr = c->lr, sv_cr = c->cr; memcpy(sv_r, c->r, sizeof sv_r);
        busy = 1; c->r[3] = req; c->r[4] = a4; c->lr = 0; { uint32_t oc = ppc_rd32(0x800000D4);
        ppc_call_indirect(c, cb); ppc_wr32(0x800000D4, oc); }
        busy = 0; memcpy(c->r, sv_r, sizeof sv_r); c->lr = sv_lr; c->cr = sv_cr;
    }
    for (int guard = 0; guard < 16 && !busy && (c->msr & 0x8000); guard++) {
        int t = -1;
        if (s_dsp_irq && (s_dsp_ctl & 0x0100)) t = OS_INTR_DSP_DSP;
        else for (int i = 0; i < 32; i++) if (s_irq_pend & (1u << i)) { t = i; break; }
        if (t < 0) return;
        if (t != OS_INTR_DSP_DSP) s_irq_pend &= ~(1u << t);
        uint32_t tab = ppc_rd32(c->r[13] - 30208);
        uint32_t h = tab ? ppc_rd32(tab + 4 * t) : 0;
        if (!h) { if (t == OS_INTR_DSP_DSP) return; continue; }
        uint32_t sv_r[32], sv_lr = c->lr, sv_cr = c->cr; memcpy(sv_r, c->r, sizeof sv_r);
        uint32_t oc = ppc_rd32(0x800000D4);
        busy = 1; c->msr &= ~0x8000u;
        c->r[3] = t; c->r[4] = oc ? oc : IRQ_CTX; c->lr = 0;
        ppc_call_indirect(c, h); ppc_wr32(0x800000D4, oc);
        busy = 0; memcpy(c->r, sv_r, sizeof sv_r); c->lr = sv_lr; c->cr = sv_cr; c->msr |= 0x8000u;
    }
}

/* tick de VI (60 Hz) chamado quando todas as threads estao paradas; TODO: entregar a IRQ de retrace de verdade */
void ppc_vi_tick(PPCContext *c) { (void)c; }
